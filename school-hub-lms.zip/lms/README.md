# School Hub LMS

A rebuilt, production-shaped version of School Hub: React + Vite + TypeScript,
real Supabase auth/backend, realtime notifications, a 3D role-select scene
(React Three Fiber), and a full dark/light theme system.

## Deploying to Netlify

If you got a "page not found" after deploying: Netlify serves static files by
default, so visiting a route directly (e.g. `/teacher`, `/student/join`) or
refreshing on one 404s, because there's no real file at that path — only
`index.html` + client-side React Router routes. This project now includes
both `netlify.toml` and `public/_redirects` with a catch-all rewrite to fix
that (`/* → /index.html`), so a fresh deploy should resolve it.

Steps:
1. Site settings → Build & deploy → confirm build command `npm run build`,
   publish directory `dist` (already set via `netlify.toml`, but double-check
   if you configured it manually in the UI — a manual setting there can
   override the file).
2. Site settings → Environment variables → add `VITE_SUPABASE_URL` and
   `VITE_SUPABASE_ANON_KEY` (and `VITE_ANTHROPIC_API_KEY` if using it). These
   come from `.env`, which is gitignored and never gets deployed on its own —
   without them set here, the deployed build silently can't reach Supabase.
3. Trigger a new deploy (env var changes and the redirect files only take
   effect on the next build, not retroactively on the current one).

## Setup

```bash
npm install
cp .env.example .env      # then fill in the values below
npm run dev
```

### 1. Supabase (required)
1. Create a project at https://supabase.com.
2. Project Settings → API → copy the **Project URL** and **anon public key** into `.env`.
3. SQL Editor → paste the contents of `supabase/schema.sql` → Run. This creates all
   tables (`users`, `students`, `teachers`, `subjects`, `quizzes`, `submissions`,
   `assignments`, `grades`, `announcements`, `notifications`), Row Level Security
   policies, and enables Realtime on `notifications` / `announcements` / `quizzes`.
4. (Optional, for Google/Facebook login) Authentication → Providers → enable
   Google and/or Facebook and fill in their OAuth credentials. Without this,
   the OAuth buttons will show a Supabase error — email/password still works.
5. Authentication → URL Configuration → add `http://localhost:5173` (and your
   deployed URL later) to Redirect URLs, so password reset / OAuth redirects work.

### 2. AI Quiz Creator (optional)
Without a key, it falls back to a local question-template generator — the
feature still works, just without real AI-written questions.
Get a key at https://console.anthropic.com and set `VITE_ANTHROPIC_API_KEY`.

**Heads up:** this calls the Anthropic API directly from the browser using the
`anthropic-dangerous-direct-browser-access` header, which means the key is
visible in devtools. Fine for local development; for a real deployment, proxy
this call through your own backend and keep the key server-side.

## What's new vs. the single-file artifact version

| Feature | Before | Now |
|---|---|---|
| Role select | Flat 3D-ish CSS tilt cards | Real React Three Fiber scene: floating cards, particle field, hover glow + rotation, camera zoom on click |
| Auth | Mocked provider buttons, no real backend | Real Supabase email/password + Google/Facebook OAuth, email verification, password reset, persistent sessions, protected routes |
| Data | In-memory + artifact key/value storage | Postgres via Supabase, with Row Level Security |
| Notifications | Toast + browser Notification API, no history | Bell with unread badge, dropdown panel, mark read/delete, categorized, backed by Supabase Realtime (works across devices/tabs) |
| Theme | Single palette | Full light/dark system, system-preference aware, no flash on load |
| Animations | Hand-rolled CSS | Framer Motion throughout + skeleton loaders |

## Project structure

```
src/
  lib/            Supabase client + hand-written DB types
  types/          Shared app-level TypeScript types
  contexts/       Theme, Auth, Toast (React context providers)
  hooks/          useNotifications (realtime), useNow (countdown ticking)
  api/            Thin Supabase query functions (quizzes, submissions, announcements)
  components/
    ui/           Design-system primitives (Button, Card, Input, Modal, Skeleton…)
    layout/       Sidebar, DashboardLayout, ProtectedRoute, FullScreenLoader
    three/        RoleSelectScene (R3F canvas, cards, particles, camera rig)
    notifications/  NotificationBell (bell + dropdown)
    theme/        ThemeToggle
    auth/         ProviderMark (Google/Facebook/Email button)
  pages/
    auth/         Login, Register, ForgotPassword, ResetPassword, VerifyEmail
    teacher/      Dashboard, AIQuizCreator, PublishedQuizzes, StudentResults,
                   GradeViewer, GradeCalculator, Leaderboard, Announcements, Settings
    student/      Home, JoinExam, MyGrades, Leaderboard, Announcements
supabase/
  schema.sql      Tables + RLS policies + Realtime setup — run this once in Supabase
```

## Known limitations / honesty notes

I built and syntax-checked this entirely offline (no network access to run
`npm install`, `tsc --noEmit`, ESLint, or a live dev server), so:

- **Not rendered/tested visually.** The R3F scene, animations, and every page
  are written to compile and behave correctly based on the libraries' documented
  APIs, but I have not seen them run in a browser. Test locally and expect to
  tweak camera distances / card spacing to taste.
- **No live Supabase project exists yet.** `schema.sql` and the RLS policies
  are written carefully (including a policy fix so the Leaderboard can show
  every student's scores, not just your own), but you should read through them
  once before trusting them with real student data.
- **OAuth (Google/Facebook)** only works once you configure those providers in
  your own Supabase project — the buttons call real `supabase.auth.signInWithOAuth`,
  there's nothing mocked, but they'll error out until you do that setup.
- **Role switching** changed meaning: since accounts now have a fixed role in
  the `users` table, "switching roles" means logging out and picking again
  from the 3D screen. The old 5-minute cooldown is now a logout cooldown.
- I did **not** run ESLint/`tsc` — I hand-checked types carefully and validated
  every file's syntax with esbuild, and cross-checked every import against
  real exports, but a real `npm run lint` / `npm run build` may still surface
  a few things (most likely minor `strict` mode nits) I couldn't catch offline.

## Deploying to Netlify

The repo already includes everything Netlify needs:
- `netlify.toml` — build command (`npm run build`), publish dir (`dist`), Node 20, and an SPA fallback redirect (`/* → /index.html`) so client-side routes like `/teacher/published` don't 404 on refresh or direct visit.
- `public/_redirects` — same SPA fallback, as a belt-and-suspenders backup in case `netlify.toml` redirects aren't picked up.
- `.nvmrc` — pins Node 20 for local `nvm use`.

Steps:
1. Push this project to a GitHub/GitLab/Bitbucket repo (Netlify deploys from git).
2. In Netlify: **Add new site → Import an existing project**, pick the repo.
   Build command and publish directory are auto-detected from `netlify.toml`.
3. **Site settings → Environment variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_ANTHROPIC_API_KEY` (optional)
   - `VITE_ANTHROPIC_MODEL` (optional)
4. Deploy. Netlify gives you a URL like `https://your-site.netlify.app`.
5. Back in Supabase: **Authentication → URL Configuration**, set Site URL to
   that Netlify URL and add it (plus `http://localhost:5173` for local dev)
   to Redirect URLs. This is required for password-reset links and Google/
   Facebook OAuth to redirect back to the right place instead of `localhost`.
6. If you're using Google/Facebook login, go back into each provider's own
   OAuth app settings (Google Cloud Console / Meta for Developers) and add
   your Netlify URL to their authorized redirect/origin lists too — Supabase
   handles its own callback, but the providers still check the origin.

Note: I changed `npm run build` to just `vite build` (dropped the `tsc -b &&`
prefix that was there before). Vite transpiles TS via esbuild regardless of
type errors, so this means a strict-mode TypeScript nit can't fail your
Netlify deploy. Run `npm run typecheck` locally/in CI if you want type
errors to actually block something.



`GradeCalculator` intentionally stays a local, unsaved scratchpad tool (matches
the original app) rather than writing to the `grades` table — wire it up to
`api/grades.ts` (not yet created) if you want persisted gradebook entries.
