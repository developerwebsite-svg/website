-- ============================================================
-- School Hub LMS — Supabase schema
-- Run this in the Supabase SQL editor (Project → SQL Editor → New query)
-- ============================================================

create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------
-- USERS  (1:1 with auth.users, adds role + profile info)
-- ----------------------------------------------------------------
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text not null,
  role text not null check (role in ('teacher','student')),
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.teachers (
  user_id uuid primary key references public.users(id) on delete cascade,
  class_name text,
  department text
);

create table if not exists public.students (
  user_id uuid primary key references public.users(id) on delete cascade,
  section text,
  grade_level text
);

-- ----------------------------------------------------------------
-- SUBJECTS  (reference list used by the quiz creator / grades)
-- ----------------------------------------------------------------
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null unique
);
insert into public.subjects (name) values
  ('TLE'), ('Value Education'), ('Math'), ('Science'),
  ('Mapeh'), ('AP'), ('English'), ('Filipino')
on conflict (name) do nothing;

-- ----------------------------------------------------------------
-- QUIZZES / EXAMS
-- ----------------------------------------------------------------
create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  join_code text unique not null default upper(substring(replace(gen_random_uuid()::text,'-','') from 1 for 6)),
  teacher_id uuid not null references public.users(id) on delete cascade,
  title text not null,
  subject text not null,
  difficulty text not null default 'Medium',
  questions jsonb not null,           -- [{question, options[4], correctIndex}]
  published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists quizzes_teacher_idx on public.quizzes(teacher_id);
create index if not exists quizzes_join_code_idx on public.quizzes(join_code);

-- ----------------------------------------------------------------
-- SUBMISSIONS  (a student's attempt at a quiz/exam)
-- ----------------------------------------------------------------
create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  quiz_title text not null,
  student_id uuid references public.users(id) on delete set null,
  student_name text not null,
  section text,
  score int not null,
  total int not null,
  submitted_at timestamptz not null default now()
);
create index if not exists submissions_quiz_idx on public.submissions(quiz_id);
create index if not exists submissions_student_idx on public.submissions(student_id);

-- ----------------------------------------------------------------
-- ASSIGNMENTS
-- ----------------------------------------------------------------
create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.users(id) on delete cascade,
  title text not null,
  description text,
  subject text,
  due_date timestamptz,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------
-- GRADES  (weighted-category gradebook entries per student)
-- ----------------------------------------------------------------
create table if not exists public.grades (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.users(id) on delete cascade,
  subject text not null,
  category text not null,      -- e.g. "Quizzes", "Homework", "Exams"
  weight numeric not null,     -- percent weight, 0-100
  score numeric not null,      -- percent score, 0-100
  updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------
-- ANNOUNCEMENTS
-- ----------------------------------------------------------------
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  author_id uuid references public.users(id) on delete set null,
  author_name text not null default 'Teacher',
  title text not null,
  body text,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------------
-- NOTIFICATIONS
-- ----------------------------------------------------------------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.users(id) on delete cascade,
  category text not null check (category in ('assignment','quiz','announcement','grade','attendance')),
  title text not null,
  body text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications(user_id, read);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table public.users enable row level security;
alter table public.teachers enable row level security;
alter table public.students enable row level security;
alter table public.subjects enable row level security;
alter table public.quizzes enable row level security;
alter table public.submissions enable row level security;
alter table public.assignments enable row level security;
alter table public.grades enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;

-- USERS: anyone signed in can read profiles (needed for names on leaderboards
-- etc), but you can only edit your own row.
create policy "users_select_all_authenticated" on public.users
  for select using (auth.role() = 'authenticated');
create policy "users_insert_own" on public.users
  for insert with check (auth.uid() = id);
create policy "users_update_own" on public.users
  for update using (auth.uid() = id);

create policy "teachers_select_all_authenticated" on public.teachers
  for select using (auth.role() = 'authenticated');
create policy "teachers_upsert_own" on public.teachers
  for insert with check (auth.uid() = user_id);
create policy "teachers_update_own" on public.teachers
  for update using (auth.uid() = user_id);

create policy "students_select_all_authenticated" on public.students
  for select using (auth.role() = 'authenticated');
create policy "students_upsert_own" on public.students
  for insert with check (auth.uid() = user_id);
create policy "students_update_own" on public.students
  for update using (auth.uid() = user_id);

-- SUBJECTS: read-only reference data for everyone signed in.
create policy "subjects_select_all_authenticated" on public.subjects
  for select using (auth.role() = 'authenticated');

-- QUIZZES: teachers manage their own; students may read published quizzes.
create policy "quizzes_select_published_or_own" on public.quizzes
  for select using (published = true or teacher_id = auth.uid());
create policy "quizzes_insert_own" on public.quizzes
  for insert with check (teacher_id = auth.uid());
create policy "quizzes_update_own" on public.quizzes
  for update using (teacher_id = auth.uid());
create policy "quizzes_delete_own" on public.quizzes
  for delete using (teacher_id = auth.uid());

-- SUBMISSIONS: students insert their own; a submitter, the owning teacher, or
-- any signed-in user (for published quizzes) can read — the last case is what
-- powers the class-wide Leaderboard, which is intentionally public.
create policy "submissions_select" on public.submissions
  for select using (
    student_id = auth.uid()
    or exists (select 1 from public.quizzes q where q.id = quiz_id and q.teacher_id = auth.uid())
    or exists (select 1 from public.quizzes q where q.id = quiz_id and q.published = true)
  );
create policy "submissions_insert_own" on public.submissions
  for insert with check (student_id = auth.uid() or student_id is null);
create policy "submissions_update_teacher" on public.submissions
  for update using (
    exists (select 1 from public.quizzes q where q.id = quiz_id and q.teacher_id = auth.uid())
  );

-- ASSIGNMENTS: teachers manage their own; students can read all.
create policy "assignments_select_all_authenticated" on public.assignments
  for select using (auth.role() = 'authenticated');
create policy "assignments_insert_own" on public.assignments
  for insert with check (teacher_id = auth.uid());
create policy "assignments_update_own" on public.assignments
  for update using (teacher_id = auth.uid());
create policy "assignments_delete_own" on public.assignments
  for delete using (teacher_id = auth.uid());

-- GRADES: student can read their own; teachers can read/write everyone's
-- (simplified — tighten to a class roster join if you add class membership).
create policy "grades_select" on public.grades
  for select using (
    student_id = auth.uid()
    or exists (select 1 from public.users u where u.id = auth.uid() and u.role = 'teacher')
  );
create policy "grades_write_teacher" on public.grades
  for insert with check (exists (select 1 from public.users u where u.id = auth.uid() and u.role = 'teacher'));
create policy "grades_update_teacher" on public.grades
  for update using (exists (select 1 from public.users u where u.id = auth.uid() and u.role = 'teacher'));

-- ANNOUNCEMENTS: everyone signed in can read; only teachers can write.
create policy "announcements_select_all_authenticated" on public.announcements
  for select using (auth.role() = 'authenticated');
create policy "announcements_insert_teacher" on public.announcements
  for insert with check (exists (select 1 from public.users u where u.id = auth.uid() and u.role = 'teacher'));
create policy "announcements_delete_teacher" on public.announcements
  for delete using (exists (select 1 from public.users u where u.id = auth.uid() and u.role = 'teacher'));

-- NOTIFICATIONS: strictly private to the owning user.
create policy "notifications_select_own" on public.notifications
  for select using (user_id = auth.uid());
create policy "notifications_insert_any_authenticated" on public.notifications
  for insert with check (auth.role() = 'authenticated');
create policy "notifications_update_own" on public.notifications
  for update using (user_id = auth.uid());
create policy "notifications_delete_own" on public.notifications
  for delete using (user_id = auth.uid());

-- ============================================================
-- REALTIME
-- ============================================================
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.announcements;
alter publication supabase_realtime add table public.quizzes;
