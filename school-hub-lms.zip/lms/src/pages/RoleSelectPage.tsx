import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { RoleSelectScene } from "@/components/three/RoleSelectScene";
import { useAuth } from "@/contexts/AuthContext";
import { FullScreenLoader } from "@/components/layout/FullScreenLoader";
import type { Role } from "@/types";

export default function RoleSelectPage() {
  const navigate = useNavigate();
  const { session, profile, loading } = useAuth();

  useEffect(() => {
    if (!loading && session && profile) {
      navigate(`/${profile.role}`, { replace: true });
    }
  }, [loading, session, profile, navigate]);

  if (loading) return <FullScreenLoader label="Checking your session…" />;
  if (session) return <FullScreenLoader label="Taking you to your dashboard…" />;

  const handleSelect = (role: Role) => {
    navigate(`/login/${role}`);
  };

  return <RoleSelectScene onSelect={handleSelect} />;
}
