import { useState } from "react";
import { motion } from "framer-motion";
import { LogIn, PlayCircle, CheckCircle2, Star } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, Button, Input } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { findQuizByJoinCode } from "@/api/quizzes";
import { submitExam } from "@/api/submissions";
import { createNotification } from "@/hooks/useNotifications";
import { supabase } from "@/lib/supabaseClient";
import type { Quiz, Submission } from "@/types";

const EXPIRY_MS = 15 * 60 * 1000;

export default function JoinExam() {
  const { profile } = useAuth();
  const [step, setStep] = useState<"find" | "details" | "take" | "done">("find");
  const [codeInput, setCodeInput] = useState("");
  const [foundQuiz, setFoundQuiz] = useState<Quiz | null>(null);
  const [section, setSection] = useState("");
  const [name, setName] = useState(profile?.fullName ?? "");
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [error, setError] = useState("");
  const [result, setResult] = useState<Submission | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const find = async () => {
    const cleanCode = codeInput.trim().toUpperCase().split("/").pop() ?? "";
    setError("");
    const q = await findQuizByJoinCode(cleanCode);
    if (!q) { setError("No published exam found with that ID or link."); return; }
    if (q.publishedAt && Date.now() - new Date(q.publishedAt).getTime() > EXPIRY_MS) {
      setError("This exam link has expired (links are only active for 15 minutes). Ask your teacher for a new one.");
      return;
    }
    setFoundQuiz(q);
    setStep("details");
  };

  const startExam = () => {
    if (!name.trim() || !section.trim()) { setError("Enter your name and section to continue."); return; }
    setError("");
    setStep("take");
  };

  const submit = async () => {
    if (!foundQuiz) return;
    setSubmitting(true);
    const total = foundQuiz.questions.length;
    let score = 0;
    foundQuiz.questions.forEach((q, i) => { if (answers[i] === q.correctIndex) score++; });
    try {
      const res = await submitExam({
        quizId: foundQuiz.id, quizTitle: foundQuiz.title, studentId: profile?.id ?? null,
        studentName: name, section, score, total,
      });
      // Let the teacher know via the realtime notification bell.
      const { data: quizRow } = await supabase.from("quizzes").select("teacher_id").eq("id", foundQuiz.id).maybeSingle();
      if (quizRow?.teacher_id) {
        await createNotification(quizRow.teacher_id, "quiz", `${name} submitted "${foundQuiz.title}"`, `Scored ${score}/${total}`);
      }
      setResult(res);
      setStep("done");
    } catch {
      setError("Couldn't submit your exam — check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  };

  if (step === "find") return (
    <div>
      <PageHeader title="Join Exam" subtitle="Paste an exam link or enter the Exam ID your teacher shared." />
      <Card style={{ maxWidth: 420 }}>
        <Input label="Exam link or ID" placeholder="e.g. AB12CD or schoolhub.app/join/AB12CD" value={codeInput} onChange={(e) => setCodeInput(e.target.value)} />
        <div style={{ fontSize: 12, color: "var(--text-faint)", marginBottom: 10, marginTop: -6 }}>Exam links stay active for 15 minutes after your teacher publishes them.</div>
        {error && <div style={{ color: "var(--red)", fontSize: 13, marginBottom: 10 }}>{error}</div>}
        <Button full icon={LogIn} onClick={find}>Find exam</Button>
      </Card>
    </div>
  );

  if (step === "details" && foundQuiz) return (
    <div>
      <PageHeader title="Almost there" subtitle={`Joining "${foundQuiz.title}"`} />
      <Card style={{ maxWidth: 420 }}>
        <Input label="Full name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" />
        <Input label="Section / Grade" value={section} onChange={(e) => setSection(e.target.value)} placeholder="e.g. Grade 9 - Section B" />
        {error && <div style={{ color: "var(--red)", fontSize: 13, marginBottom: 10 }}>{error}</div>}
        <div style={{ display: "flex", gap: 8 }}>
          <Button variant="ghost" onClick={() => setStep("find")}>Back</Button>
          <Button icon={PlayCircle} onClick={startExam} full>Start exam</Button>
        </div>
      </Card>
    </div>
  );

  if (step === "take" && foundQuiz) return (
    <div>
      <PageHeader title={foundQuiz.title} subtitle={`${foundQuiz.questions.length} questions · Good luck, ${name.split(" ")[0]}!`} />
      <Card>
        {foundQuiz.questions.map((q, qi) => (
          <div key={qi} style={{ padding: "14px 0", borderTop: qi ? "1px solid var(--border)" : "none" }}>
            <div style={{ fontWeight: 700, fontSize: 14.5, marginBottom: 10 }}>{qi + 1}. {q.question}</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {q.options.map((opt, oi) => (
                <label key={oi} style={{ display: "flex", alignItems: "center", gap: 8, padding: "9px 11px", borderRadius: 9, border: `1.5px solid ${answers[qi] === oi ? "var(--blue)" : "var(--border)"}`, background: answers[qi] === oi ? "color-mix(in srgb, var(--blue) 14%, transparent)" : "var(--surface)", cursor: "pointer" }}>
                  <input type="radio" name={`q${qi}`} checked={answers[qi] === oi} onChange={() => setAnswers({ ...answers, [qi]: oi })} />
                  <span style={{ fontSize: 13.5 }}>{opt}</span>
                </label>
              ))}
            </div>
          </div>
        ))}
        {error && <div style={{ color: "var(--red)", fontSize: 13, marginTop: 10 }}>{error}</div>}
        <div style={{ marginTop: 16, display: "flex", justifyContent: "flex-end" }}>
          <Button variant="blue" icon={CheckCircle2} onClick={submit} disabled={submitting || Object.keys(answers).length < foundQuiz.questions.length}>
            {submitting ? "Submitting…" : "Submit exam"}
          </Button>
        </div>
      </Card>
    </div>
  );

  if (step === "done" && result) return (
    <div>
      <PageHeader title="Exam submitted!" subtitle="Nice work — here's how you did." />
      <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 260, damping: 20 }}>
        <Card style={{ maxWidth: 360, textAlign: "center", padding: 32 }}>
          <Star size={30} style={{ color: "var(--gold)", marginBottom: 8 }} />
          <div className="sh-display" style={{ fontSize: 42, fontWeight: 700, color: "var(--chalk)" }}>{result.score}/{result.total}</div>
          <div style={{ fontSize: 13, color: "var(--text-faint)", marginBottom: 16 }}>{Math.round((result.score / result.total) * 100)}% on {result.quizTitle}</div>
          <Button full onClick={() => { setStep("find"); setCodeInput(""); setFoundQuiz(null); setAnswers({}); setResult(null); }}>Join another exam</Button>
        </Card>
      </motion.div>
    </div>
  );

  return null;
}
