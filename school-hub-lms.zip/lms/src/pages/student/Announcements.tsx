import { AnnouncementsView } from "@/components/AnnouncementsView";

export default function StudentAnnouncements() {
  return <AnnouncementsView editable={false} />;
}
