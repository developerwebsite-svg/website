import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { PlayCircle, Award, Trophy, Megaphone } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, EmptyState, SkeletonList } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { listAnnouncements } from "@/api/announcements";
import type { Announcement } from "@/types";

function QuickCard({ icon: Icon, title, desc, tone, onClick }: { icon: React.ElementType; title: string; desc: string; tone: string; onClick: () => void }) {
  return (
    <motion.button whileHover={{ y: -4, scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={onClick} style={{ textAlign: "left", border: "none", cursor: "pointer", background: "transparent", padding: 0 }}>
      <div className="card-surface" style={{ padding: 20, borderTop: `4px solid ${tone}` }}>
        <Icon size={24} style={{ color: tone, marginBottom: 10 }} />
        <div className="sh-display" style={{ fontWeight: 700, fontSize: 15 }}>{title}</div>
        <div style={{ fontSize: 12.5, color: "var(--text-faint)" }}>{desc}</div>
      </div>
    </motion.button>
  );
}

export default function StudentHome() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listAnnouncements().then(setAnnouncements).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <PageHeader title={`Welcome, ${profile?.fullName?.split(" ")[0] ?? "there"} 👋`} subtitle="Jump into an exam, check your grades, or see the board." />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 14, marginBottom: 20 }}>
        <QuickCard icon={PlayCircle} title="Join an Exam" desc="Enter an Exam ID or link" tone="var(--blue)" onClick={() => navigate("/student/join")} />
        <QuickCard icon={Award} title="My Grades" desc="See how you've scored" tone="var(--gold)" onClick={() => navigate("/student/grades")} />
        <QuickCard icon={Trophy} title="Leaderboard" desc="See the class rankings" tone="var(--chalk)" onClick={() => navigate("/student/leaderboard")} />
      </div>
      <Card>
        <div className="sh-display" style={{ fontWeight: 700, marginBottom: 10, fontSize: 15 }}>Latest announcements</div>
        {loading ? (
          <SkeletonList rows={2} />
        ) : announcements.length === 0 ? (
          <EmptyState icon={Megaphone} title="Nothing new" body="Check back later for class updates." />
        ) : (
          announcements.slice(0, 3).map((a) => (
            <div key={a.id} style={{ padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
              <div style={{ fontWeight: 700, fontSize: 13.5 }}>{a.title}</div>
              <div style={{ fontSize: 12.5, color: "var(--text-faint)" }}>{a.body}</div>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}
