import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import { LeaderboardView } from "@/components/LeaderboardView";
import { SkeletonList } from "@/components/ui";
import type { Submission } from "@/types";
import type { SubmissionsRow } from "@/lib/database.types";

export default function StudentLeaderboardPage() {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("submissions")
      .select("*")
      .order("submitted_at", { ascending: false })
      .limit(500)
      .then(({ data }) => {
        setSubmissions(
          (data ?? []).map((row: SubmissionsRow) => ({
            id: row.id, quizId: row.quiz_id, quizTitle: row.quiz_title, studentId: row.student_id,
            studentName: row.student_name, section: row.section, score: row.score, total: row.total, submittedAt: row.submitted_at,
          }))
        );
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <SkeletonList rows={5} />;
  return <LeaderboardView submissions={submissions} />;
}
