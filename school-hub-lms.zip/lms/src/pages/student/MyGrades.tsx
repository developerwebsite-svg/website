import { useEffect, useState } from "react";
import { Award, Clock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, EmptyState, SkeletonList } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { listSubmissionsForStudent } from "@/api/submissions";
import type { Submission } from "@/types";

export default function MyGrades() {
  const { profile } = useAuth();
  const [mine, setMine] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    listSubmissionsForStudent(profile.id).then(setMine).finally(() => setLoading(false));
  }, [profile]);

  return (
    <div>
      <PageHeader title="My Grades" subtitle={profile ? `Showing results for ${profile.fullName}` : "Sign in to see your results."} />
      {profile && (
        <Card style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16, padding: 16 }}>
          <div style={{ width: 40, height: 40, borderRadius: "50%", background: "var(--chalk)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, flexShrink: 0 }}>
            {profile.fullName.trim().charAt(0).toUpperCase()}
          </div>
          <div>
            <div className="sh-display" style={{ fontWeight: 700, fontSize: 15 }}>{profile.fullName}</div>
            <div style={{ fontSize: 12, color: "var(--text-faint)" }}>{mine.length} exam{mine.length === 1 ? "" : "s"} taken</div>
          </div>
        </Card>
      )}
      {loading ? (
        <SkeletonList rows={3} />
      ) : mine.length === 0 ? (
        <Card><EmptyState icon={Award} title="No results yet" body="Once you complete an exam, your name, score, and the date you took it will show here." /></Card>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(230px,1fr))", gap: 14 }}>
          {mine.map((s) => (
            <Card key={s.id}>
              <div className="sh-display" style={{ fontWeight: 700, fontSize: 15, marginBottom: 6 }}>{s.quizTitle}</div>
              <div style={{ fontSize: 26, fontWeight: 700, color: "var(--chalk)" }}>{Math.round((s.score / s.total) * 100)}%</div>
              <div style={{ fontSize: 12.5, color: "var(--text-faint)" }}>{s.score} / {s.total} correct · {s.studentName}</div>
              <div style={{ fontSize: 11.5, color: "var(--text-faint)", marginTop: 6, display: "flex", alignItems: "center", gap: 5 }}>
                <Clock size={11} /> Taken {new Date(s.submittedAt).toLocaleString()}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
