import { useState } from "react";
import { Link } from "react-router-dom";
import { Mail, CheckCircle2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button, Input } from "@/components/ui";
import { AuthShell, ErrorLine } from "./Login";

export default function ForgotPassword() {
  const { sendPasswordReset } = useAuth();
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) { setError("Enter your email address."); return; }
    setError(""); setLoading(true);
    const { error: err } = await sendPasswordReset(email);
    setLoading(false);
    if (err) setError(err);
    else setSent(true);
  };

  return (
    <AuthShell emoji="🔑" title="Reset your password" subtitle="We'll email you a link to set a new one.">
      {sent ? (
        <div style={{ textAlign: "center", padding: "10px 0" }}>
          <CheckCircle2 size={30} style={{ color: "var(--chalk)", marginBottom: 10 }} />
          <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 4 }}>Check your inbox</div>
          <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>We sent a reset link to {email}.</div>
        </div>
      ) : (
        <form onSubmit={submit}>
          <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@school.edu" autoComplete="email" />
          {error && <ErrorLine>{error}</ErrorLine>}
          <Button type="submit" icon={Mail} disabled={loading} full>{loading ? "Sending…" : "Send reset link"}</Button>
        </form>
      )}
      <div style={{ textAlign: "center", marginTop: 16 }}>
        <Link to="/" style={{ fontSize: 12, color: "var(--text-faint)", textDecoration: "none" }}>← Back to role select</Link>
      </div>
    </AuthShell>
  );
}
