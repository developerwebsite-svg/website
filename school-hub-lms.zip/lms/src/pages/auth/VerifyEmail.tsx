import { useLocation, Link } from "react-router-dom";
import { MailCheck } from "lucide-react";
import { AuthShell } from "./Login";

export default function VerifyEmail() {
  const location = useLocation();
  const email = (location.state as { email?: string } | null)?.email;

  return (
    <AuthShell emoji="📬" title="Verify your email" subtitle="One last step before you can sign in.">
      <div style={{ textAlign: "center", padding: "6px 0 14px" }}>
        <MailCheck size={30} style={{ color: "var(--chalk)", marginBottom: 10 }} />
        <div style={{ fontSize: 13.5, color: "var(--text)", marginBottom: 4 }}>
          We sent a confirmation link{email ? ` to ${email}` : ""}.
        </div>
        <div style={{ fontSize: 12.5, color: "var(--text-muted)" }}>
          Click the link in that email, then come back and sign in.
        </div>
      </div>
      <Link to="/" style={{ display: "block", textAlign: "center", fontSize: 12.5, color: "var(--blue)", fontWeight: 600, textDecoration: "none" }}>
        ← Back to role select
      </Link>
    </AuthShell>
  );
}
