import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { LogIn, AlertTriangle } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button, Card, Input } from "@/components/ui";
import { ProviderButton } from "@/components/auth/ProviderMark";
import type { Role } from "@/types";

export default function Login() {
  const { role } = useParams<{ role: Role }>();
  const navigate = useNavigate();
  const { signIn, signInWithOAuth, session, profile } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (session && profile) {
      if (role && profile.role !== role) {
        setError(`This account is registered as a ${profile.role}. Redirecting you there…`);
        setTimeout(() => navigate(`/${profile.role}`, { replace: true }), 1200);
      } else {
        navigate(`/${profile.role}`, { replace: true });
      }
    }
  }, [session, profile, role, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) { setError("Enter your email and password."); return; }
    setError(""); setLoading(true);
    const { error: err } = await signIn(email, password);
    setLoading(false);
    if (err) setError(err);
  };

  return (
    <AuthShell emoji={role === "teacher" ? "👨‍🏫" : "👨‍🎓"} title="Welcome back" subtitle={`Sign in to continue as a ${role ?? "user"}.`}>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 16 }}>
        <ProviderButton provider="google" onClick={async () => { const { error: err } = await signInWithOAuth("google"); if (err) setError(err); }}>
          Continue with Google
        </ProviderButton>
        <ProviderButton provider="facebook" onClick={async () => { const { error: err } = await signInWithOAuth("facebook"); if (err) setError(err); }}>
          Continue with Facebook
        </ProviderButton>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "16px 0", color: "var(--text-faint)", fontSize: 11.5 }}>
        <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
        OR
        <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
      </div>
      <form onSubmit={submit}>
        <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@school.edu" autoComplete="email" />
        <Input label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" autoComplete="current-password" />
        {error && <ErrorLine>{error}</ErrorLine>}
        <Button type="submit" icon={LogIn} disabled={loading} full>{loading ? "Signing in…" : "Sign in"}</Button>
      </form>
      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 14, fontSize: 12.5 }}>
        <Link to="/forgot-password" style={{ color: "var(--blue)", fontWeight: 600, textDecoration: "none" }}>Forgot password?</Link>
        <Link to={`/register/${role ?? "student"}`} style={{ color: "var(--text-muted)", fontWeight: 600, textDecoration: "none" }}>Create an account</Link>
      </div>
      <div style={{ textAlign: "center", marginTop: 18 }}>
        <Link to="/" style={{ fontSize: 12, color: "var(--text-faint)", textDecoration: "none" }}>← Back to role select</Link>
      </div>
    </AuthShell>
  );
}

export function AuthShell({ emoji, title, subtitle, children }: { emoji: string; title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div style={{ minHeight: "100vh", background: "radial-gradient(circle at 20% 15%, #2f7a6333, transparent 45%), var(--chalk)", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <Card animate style={{ width: "100%", maxWidth: 380, padding: 28 }}>
        <div style={{ textAlign: "center", marginBottom: 18 }}>
          <div style={{ fontSize: 34, marginBottom: 6 }}>{emoji}</div>
          <div className="sh-display" style={{ fontWeight: 700, fontSize: 19 }}>{title}</div>
          <div style={{ fontSize: 12.5, color: "var(--text-muted)", marginTop: 4 }}>{subtitle}</div>
        </div>
        {children}
      </Card>
    </div>
  );
}

export function ErrorLine({ children }: { children: React.ReactNode }) {
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "center", color: "var(--red)", fontSize: 12.5, marginBottom: 10 }}>
      <AlertTriangle size={13} /> {children}
    </div>
  );
}
