import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { KeyRound } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button, Input } from "@/components/ui";
import { AuthShell, ErrorLine } from "./Login";

export default function ResetPassword() {
  const { updatePassword } = useAuth();
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) { setError("Password must be at least 6 characters."); return; }
    if (password !== confirm) { setError("Passwords don't match."); return; }
    setError(""); setLoading(true);
    const { error: err } = await updatePassword(password);
    setLoading(false);
    if (err) { setError(err); return; }
    navigate("/", { replace: true });
  };

  return (
    <AuthShell emoji="🔒" title="Set a new password" subtitle="Choose a new password for your account.">
      <form onSubmit={submit}>
        <Input label="New password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" autoComplete="new-password" />
        <Input label="Confirm new password" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Repeat password" autoComplete="new-password" />
        {error && <ErrorLine>{error}</ErrorLine>}
        <Button type="submit" icon={KeyRound} disabled={loading} full>{loading ? "Saving…" : "Save new password"}</Button>
      </form>
    </AuthShell>
  );
}
