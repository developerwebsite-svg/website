import { useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { UserPlus } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button, Input } from "@/components/ui";
import { ProviderButton } from "@/components/auth/ProviderMark";
import { AuthShell, ErrorLine } from "./Login";
import type { Role } from "@/types";

export default function Register() {
  const { role: paramRole } = useParams<{ role: Role }>();
  const role: Role = paramRole === "teacher" ? "teacher" : "student";
  const navigate = useNavigate();
  const { signUp, signInWithOAuth } = useAuth();

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !email.trim() || !password) { setError("Fill in all fields to continue."); return; }
    if (password.length < 6) { setError("Password must be at least 6 characters."); return; }
    if (password !== confirm) { setError("Passwords don't match."); return; }
    setError(""); setLoading(true);
    const { error: err, needsVerification } = await signUp({ email, password, fullName, role });
    setLoading(false);
    if (err) { setError(err); return; }
    if (needsVerification) navigate("/verify-email", { state: { email } });
    else navigate(`/${role}`, { replace: true });
  };

  return (
    <AuthShell emoji={role === "teacher" ? "👨‍🏫" : "👨‍🎓"} title="Create your account" subtitle={`Sign up as a ${role} — no going back and forth, this is locked to your role.`}>
      <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 16 }}>
        <ProviderButton provider="google" onClick={async () => { const { error: err } = await signInWithOAuth("google"); if (err) setError(err); }}>
          Continue with Google
        </ProviderButton>
        <ProviderButton provider="facebook" onClick={async () => { const { error: err } = await signInWithOAuth("facebook"); if (err) setError(err); }}>
          Continue with Facebook
        </ProviderButton>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "16px 0", color: "var(--text-faint)", fontSize: 11.5 }}>
        <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
        OR
        <div style={{ flex: 1, height: 1, background: "var(--border)" }} />
      </div>
      <form onSubmit={submit}>
        <Input label="Full name" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Jane Doe" autoComplete="name" />
        <Input label="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@school.edu" autoComplete="email" />
        <Input label="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 6 characters" autoComplete="new-password" />
        <Input label="Confirm password" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Repeat password" autoComplete="new-password" />
        {error && <ErrorLine>{error}</ErrorLine>}
        <Button type="submit" icon={UserPlus} disabled={loading} full>{loading ? "Creating account…" : "Create account"}</Button>
      </form>
      <div style={{ textAlign: "center", marginTop: 14, fontSize: 12.5 }}>
        Already have an account? <Link to={`/login/${role}`} style={{ color: "var(--blue)", fontWeight: 600, textDecoration: "none" }}>Sign in</Link>
      </div>
      <div style={{ textAlign: "center", marginTop: 10 }}>
        <Link to="/" style={{ fontSize: 12, color: "var(--text-faint)", textDecoration: "none" }}>← Back to role select</Link>
      </div>
    </AuthShell>
  );
}
