import { useState } from "react";
import { Trash2, Plus } from "lucide-react";
import { Card, Button, Pill } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";

interface Row {
  id: string;
  label: string;
  weight: number;
  score: number;
}
const uid = () => Math.random().toString(36).slice(2, 9);

export default function GradeCalculator() {
  const [rows, setRows] = useState<Row[]>([
    { id: uid(), label: "Quizzes", weight: 40, score: 90 },
    { id: uid(), label: "Homework", weight: 20, score: 85 },
    { id: uid(), label: "Exams", weight: 40, score: 78 },
  ]);

  const totalWeight = rows.reduce((a, r) => a + Number(r.weight || 0), 0);
  const final = rows.reduce((a, r) => a + (Number(r.weight || 0) * Number(r.score || 0)) / 100, 0);
  const update = (id: string, field: keyof Row, value: string | number) => setRows((rs) => rs.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
  const addRow = () => setRows((rs) => [...rs, { id: uid(), label: "New category", weight: 0, score: 0 }]);
  const removeRow = (id: string) => setRows((rs) => rs.filter((r) => r.id !== id));

  let letter = "F";
  if (final >= 90) letter = "A";
  else if (final >= 80) letter = "B";
  else if (final >= 70) letter = "C";
  else if (final >= 60) letter = "D";

  return (
    <div>
      <PageHeader title="Grade Calculator" subtitle="Weight each category to compute a final grade. This is a scratchpad — nothing here is saved." />
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <Card>
          {rows.map((r) => (
            <div key={r.id} style={{ display: "grid", gridTemplateColumns: "1.4fr .7fr .7fr auto", gap: 8, alignItems: "center", marginBottom: 10 }}>
              <input value={r.label} onChange={(e) => update(r.id, "label", e.target.value)} style={fieldStyle} />
              <div style={{ position: "relative" }}>
                <input type="number" value={r.weight} onChange={(e) => update(r.id, "weight", Number(e.target.value))} style={fieldStyle} />
                <span style={{ position: "absolute", right: 10, top: 9, fontSize: 12, color: "var(--text-faint)" }}>%wt</span>
              </div>
              <div style={{ position: "relative" }}>
                <input type="number" value={r.score} onChange={(e) => update(r.id, "score", Number(e.target.value))} style={fieldStyle} />
                <span style={{ position: "absolute", right: 10, top: 9, fontSize: 12, color: "var(--text-faint)" }}>score</span>
              </div>
              <button onClick={() => removeRow(r.id)} style={{ background: "none", border: "none", color: "var(--red)", cursor: "pointer" }}><Trash2 size={16} /></button>
            </div>
          ))}
          <Button size="sm" variant="ghost" icon={Plus} onClick={addRow}>Add category</Button>
          {totalWeight !== 100 && <div style={{ marginTop: 10, fontSize: 12.5, color: "var(--red)" }}>Weights total {totalWeight}% — should add up to 100%.</div>}
        </Card>
        <Card style={{ textAlign: "center", display: "flex", flexDirection: "column", justifyContent: "center" }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: "var(--text-faint)", textTransform: "uppercase" }}>Final grade</div>
          <div className="sh-display" style={{ fontSize: 52, fontWeight: 700, color: "var(--chalk)", margin: "8px 0" }}>{final.toFixed(1)}%</div>
          <Pill tone={letter === "A" || letter === "B" ? "chalk" : letter === "C" ? "gold" : "red"}>Letter grade: {letter}</Pill>
        </Card>
      </div>
    </div>
  );
}

const fieldStyle: React.CSSProperties = { width: "100%", padding: "9px 10px", borderRadius: 9, border: "1.5px solid var(--border)", background: "var(--surface)", color: "var(--text)" };
