import { AnnouncementsView } from "@/components/AnnouncementsView";

export default function TeacherAnnouncements() {
  return <AnnouncementsView editable />;
}
