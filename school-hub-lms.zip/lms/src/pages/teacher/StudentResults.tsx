import { useEffect, useState } from "react";
import { Users } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, EmptyState, Pill, Select, SkeletonList } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { listQuizzesForTeacher } from "@/api/quizzes";
import { listSubmissionsForTeacher } from "@/api/submissions";
import type { Quiz, Submission } from "@/types";

export default function StudentResults() {
  const { profile } = useAuth();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    Promise.all([listQuizzesForTeacher(profile.id), listSubmissionsForTeacher(profile.id)])
      .then(([q, s]) => { setQuizzes(q); setSubmissions(s); })
      .finally(() => setLoading(false));
  }, [profile]);

  const filtered = filter === "all" ? submissions : submissions.filter((s) => s.quizId === filter);

  return (
    <div>
      <PageHeader
        title="Student Results"
        subtitle="Every submission, across every exam."
        right={
          <Select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All exams</option>
            {quizzes.map((q) => <option key={q.id} value={q.id}>{q.title}</option>)}
          </Select>
        }
      />
      {loading ? (
        <SkeletonList rows={5} />
      ) : (
        <Card style={{ padding: 0, overflow: "hidden" }}>
          {filtered.length === 0 ? (
            <div style={{ padding: 20 }}><EmptyState icon={Users} title="No submissions yet" body="Results will appear as students complete exams." /></div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
              <thead>
                <tr style={{ background: "var(--bg-sunken)", textAlign: "left" }}>
                  {["Student", "Section", "Exam", "Score", "Submitted"].map((h) => (
                    <th key={h} style={{ padding: "10px 16px", fontSize: 11.5, color: "var(--text-faint)", textTransform: "uppercase", fontWeight: 700 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr key={s.id} style={{ borderTop: "1px solid var(--border)" }}>
                    <td style={{ padding: "10px 16px", fontWeight: 600 }}>{s.studentName}</td>
                    <td style={{ padding: "10px 16px" }}>{s.section ?? "—"}</td>
                    <td style={{ padding: "10px 16px" }}>{s.quizTitle}</td>
                    <td style={{ padding: "10px 16px" }}><Pill tone={s.score / s.total >= 0.6 ? "chalk" : "red"}>{s.score}/{s.total}</Pill></td>
                    <td style={{ padding: "10px 16px", color: "var(--text-faint)" }}>{new Date(s.submittedAt).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}
    </div>
  );
}
