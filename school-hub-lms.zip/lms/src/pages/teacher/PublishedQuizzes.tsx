import { useEffect, useState } from "react";
import { ClipboardList, Pencil, Link2, Rocket, Trash2, Copy, Check, Plus, Clock } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/contexts/ToastContext";
import { Card, Button, Pill, Modal, Input, EmptyState, SkeletonCard } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { PseudoQR } from "@/components/PseudoQR";
import { listQuizzesForTeacher, updateQuiz, deleteQuiz } from "@/api/quizzes";
import type { Quiz } from "@/types";
import type { QuizQuestion } from "@/lib/database.types";

const EXPIRY_MS = 15 * 60 * 1000;
const timeLeft = (q: Quiz) => (q.publishedAt ? Math.max(0, EXPIRY_MS - (Date.now() - new Date(q.publishedAt).getTime())) : 0);

function QuizEditor({ quiz, onSave, onCancel }: { quiz: Quiz; onSave: (title: string, questions: QuizQuestion[]) => void; onCancel: () => void }) {
  const [title, setTitle] = useState(quiz.title);
  const [questions, setQuestions] = useState<QuizQuestion[]>(JSON.parse(JSON.stringify(quiz.questions)));

  const updateQuestion = (i: number, field: keyof QuizQuestion, value: any) => {
    const qs = [...questions]; qs[i] = { ...qs[i], [field]: value }; setQuestions(qs);
  };
  const updateOption = (qi: number, oi: number, value: string) => {
    const qs = [...questions]; const opts = [...qs[qi].options]; opts[oi] = value; qs[qi] = { ...qs[qi], options: opts }; setQuestions(qs);
  };
  const addQuestion = () => setQuestions((qs) => [...qs, { question: "New question", options: ["Option A", "Option B", "Option C", "Option D"], correctIndex: 0 }]);
  const removeQuestion = (i: number) => setQuestions((qs) => qs.filter((_, idx) => idx !== i));

  return (
    <div>
      <Input label="Exam title" value={title} onChange={(e) => setTitle(e.target.value)} />
      {questions.map((qq, qi) => (
        <div key={qi} style={{ padding: "12px 0", borderTop: "1px solid var(--border)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "var(--chalk)" }}>QUESTION {qi + 1}</div>
            <button onClick={() => removeQuestion(qi)} style={{ background: "none", border: "none", color: "var(--red)", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, fontSize: 11, fontWeight: 700 }}><Trash2 size={12} /> Remove</button>
          </div>
          <input value={qq.question} onChange={(e) => updateQuestion(qi, "question", e.target.value)} style={{ width: "100%", fontWeight: 600, fontSize: 14, border: "none", outline: "none", marginBottom: 8, background: "transparent", color: "var(--text)" }} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
            {qq.options.map((opt, oi) => (
              <label key={oi} style={{ display: "flex", gap: 6, alignItems: "center", padding: "6px 8px", borderRadius: 8, border: `1px solid ${qq.correctIndex === oi ? "var(--chalk)" : "var(--border)"}` }}>
                <input type="radio" checked={qq.correctIndex === oi} onChange={() => updateQuestion(qi, "correctIndex", oi)} />
                <input value={opt} onChange={(e) => updateOption(qi, oi, e.target.value)} style={{ border: "none", outline: "none", fontSize: 13, flex: 1, background: "transparent", color: "var(--text)" }} />
              </label>
            ))}
          </div>
        </div>
      ))}
      <div style={{ paddingTop: 10 }}><Button size="sm" variant="ghost" icon={Plus} onClick={addQuestion}>Add question</Button></div>
      <div style={{ display: "flex", gap: 8, marginTop: 16, justifyContent: "flex-end" }}>
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
        <Button variant="primary" icon={Check} onClick={() => onSave(title, questions)}>Save changes</Button>
      </div>
    </div>
  );
}

export default function PublishedQuizzes() {
  const { profile } = useAuth();
  const { pushToast } = useToast();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [shareQuiz, setShareQuiz] = useState<Quiz | null>(null);
  const [editQuiz, setEditQuiz] = useState<Quiz | null>(null);
  const [, forceTick] = useState(0);

  useEffect(() => {
    if (!profile) return;
    listQuizzesForTeacher(profile.id).then(setQuizzes).finally(() => setLoading(false));
  }, [profile]);

  // Re-render every 30s so the "expires in Xm" labels stay roughly fresh.
  useEffect(() => {
    const id = setInterval(() => forceTick((n) => n + 1), 30000);
    return () => clearInterval(id);
  }, []);

  const del = async (id: string) => {
    setQuizzes((qs) => qs.filter((q) => q.id !== id));
    try { await deleteQuiz(id); } catch { pushToast("Couldn't delete", "Please try again.", "error"); }
  };

  const togglePublish = async (q: Quiz) => {
    const nowPublished = !q.published;
    const publishedAt = nowPublished ? new Date().toISOString() : null;
    setQuizzes((qs) => qs.map((x) => (x.id === q.id ? { ...x, published: nowPublished, publishedAt } : x)));
    try { await updateQuiz(q.id, { published: nowPublished, publishedAt }); } catch { pushToast("Couldn't update", "Please try again.", "error"); }
  };

  const saveEdit = async (title: string, questions: QuizQuestion[]) => {
    if (!editQuiz) return;
    setQuizzes((qs) => qs.map((x) => (x.id === editQuiz.id ? { ...x, title, questions } : x)));
    try { await updateQuiz(editQuiz.id, { title, questions }); pushToast("Saved", title, "success"); } catch { pushToast("Couldn't save", "Please try again.", "error"); }
    setEditQuiz(null);
  };

  if (loading) {
    return (
      <div>
        <PageHeader title="Published Quizzes" subtitle="Manage, share, and update every exam you've built." />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(270px,1fr))", gap: 14 }}>
          {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Published Quizzes" subtitle="Manage, share, and update every exam you've built." />
      {quizzes.length === 0 ? (
        <Card><EmptyState icon={ClipboardList} title="No exams yet" body="Head to AI Quiz Creator to build your first one." /></Card>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(270px,1fr))", gap: 14 }}>
          {quizzes.map((q) => {
            const left = timeLeft(q);
            return (
              <Card key={q.id} style={{ padding: 18 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8, gap: 6, flexWrap: "wrap" }}>
                  <Pill tone={q.published ? (left > 0 ? "chalk" : "red") : "gold"}>{q.published ? (left > 0 ? "Published" : "Link expired") : "Draft"}</Pill>
                  <span style={{ fontSize: 11, color: "var(--text-faint)", fontWeight: 700 }}>#{q.joinCode}</span>
                </div>
                <div className="sh-display" style={{ fontWeight: 700, fontSize: 16.5, marginBottom: 4 }}>{q.title}</div>
                <div style={{ fontSize: 12.5, color: "var(--text-faint)", marginBottom: 4 }}>{q.subject} · {q.difficulty} · {q.questions.length} questions</div>
                {q.published && (
                  <div style={{ fontSize: 11.5, color: left > 0 ? "var(--blue)" : "var(--red)", marginBottom: 10, display: "flex", alignItems: "center", gap: 5, fontWeight: 600 }}>
                    <Clock size={12} /> {left > 0 ? `Join link active for ${Math.ceil(left / 60000)} more min` : "Link expired — republish for a fresh window"}
                  </div>
                )}
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  <Button size="sm" variant="ghost" icon={Pencil} onClick={() => setEditQuiz(q)}>Edit</Button>
                  <Button size="sm" variant="ghost" icon={Link2} onClick={() => setShareQuiz(q)}>Share</Button>
                  <Button size="sm" variant={q.published ? "gold" : "primary"} icon={Rocket} onClick={() => togglePublish(q)}>{q.published ? "Unpublish" : "Publish"}</Button>
                  <Button size="sm" variant="danger" icon={Trash2} onClick={() => del(q.id)}>Delete</Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={!!shareQuiz} onClose={() => setShareQuiz(null)} title="Share exam">
        {shareQuiz && (
          <div style={{ textAlign: "center" }}>
            <div style={{ display: "inline-block", padding: 10, background: "#fff", borderRadius: 14, boxShadow: "0 8px 20px -10px rgba(0,0,0,.3)", marginBottom: 14 }}>
              <PseudoQR value={shareQuiz.joinCode} />
            </div>
            <div style={{ fontSize: 12, color: "var(--text-faint)", marginBottom: 14 }}>Students can enter this Exam ID on the Join Exam tab.</div>
            <div style={{ display: "flex", gap: 8, marginBottom: 6 }}>
              <div style={{ flex: 1, padding: "10px 12px", borderRadius: 10, background: "var(--surface)", border: "1.5px solid var(--border)", fontFamily: "monospace", fontSize: 13.5, textAlign: "left", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                schoolhub.app/join/{shareQuiz.joinCode}
              </div>
              <Button size="sm" icon={Copy} onClick={() => navigator.clipboard?.writeText(`schoolhub.app/join/${shareQuiz.joinCode}`)}>Copy</Button>
            </div>
            <div className="sh-display" style={{ fontSize: 22, fontWeight: 700, letterSpacing: 2, marginTop: 14, color: "var(--chalk)" }}>{shareQuiz.joinCode}</div>
            <div style={{ fontSize: 11, color: "var(--text-faint)" }}>Exam ID · active 15 min after publishing</div>
          </div>
        )}
      </Modal>

      <Modal open={!!editQuiz} onClose={() => setEditQuiz(null)} title="Edit exam" width={560}>
        {editQuiz && <QuizEditor quiz={editQuiz} onSave={saveEdit} onCancel={() => setEditQuiz(null)} />}
      </Modal>
    </div>
  );
}
