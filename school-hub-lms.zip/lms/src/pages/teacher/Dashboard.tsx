import { useEffect, useState } from "react";
import { ClipboardList, Rocket, FileText, Award, BarChart3, Sparkles, Megaphone } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell } from "recharts";
import { useAuth } from "@/contexts/AuthContext";
import { Card, EmptyState, SkeletonCard } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { listQuizzesForTeacher } from "@/api/quizzes";
import { listSubmissionsForTeacher } from "@/api/submissions";
import { listAnnouncements } from "@/api/announcements";
import type { Quiz, Submission, Announcement } from "@/types";

function StatCard({ icon: Icon, label, value, tone }: { icon: React.ElementType; label: string; value: string | number; tone: string }) {
  return (
    <Card style={{ padding: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{ width: 38, height: 38, borderRadius: 10, background: `color-mix(in srgb, ${tone} 16%, transparent)`, display: "flex", alignItems: "center", justifyContent: "center", color: tone }}>
          <Icon size={19} />
        </div>
        <div>
          <div className="sh-display" style={{ fontSize: 20, fontWeight: 700 }}>{value}</div>
          <div style={{ fontSize: 12, color: "var(--text-faint)" }}>{label}</div>
        </div>
      </div>
    </Card>
  );
}

export default function TeacherDashboard() {
  const { profile } = useAuth();
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      setLoading(true);
      const [q, s, a] = await Promise.all([
        listQuizzesForTeacher(profile.id).catch(() => []),
        listSubmissionsForTeacher(profile.id).catch(() => []),
        listAnnouncements().catch(() => []),
      ]);
      setQuizzes(q); setSubmissions(s); setAnnouncements(a);
      setLoading(false);
    })();
  }, [profile]);

  if (loading) {
    return (
      <div>
        <PageHeader title="Dashboard" subtitle="A quick look at how your classroom is doing." />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 14 }}>
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      </div>
    );
  }

  const published = quizzes.filter((q) => q.published);
  const avgScore = submissions.length ? Math.round(submissions.reduce((a, s) => a + (s.score / s.total) * 100, 0) / submissions.length) : 0;
  const perQuiz = quizzes.map((q) => {
    const subs = submissions.filter((s) => s.quizId === q.id);
    const avg = subs.length ? Math.round(subs.reduce((a, s) => a + (s.score / s.total) * 100, 0) / subs.length) : 0;
    return { name: q.title.length > 12 ? q.title.slice(0, 12) + "…" : q.title, avg };
  });
  const pieData = [
    { name: "Published", value: published.length, color: "var(--chalk)" },
    { name: "Drafts", value: quizzes.length - published.length, color: "var(--gold)" },
  ];

  return (
    <div>
      <PageHeader title={`Welcome back, ${profile?.fullName?.split(" ")[0] ?? "Teacher"} 👋`} subtitle="A quick look at how your classroom is doing." />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 14, marginBottom: 22 }}>
        <StatCard icon={ClipboardList} label="Quizzes created" value={quizzes.length} tone="var(--chalk)" />
        <StatCard icon={Rocket} label="Published" value={published.length} tone="var(--blue)" />
        <StatCard icon={FileText} label="Submissions" value={submissions.length} tone="var(--gold)" />
        <StatCard icon={Award} label="Average score" value={`${avgScore}%`} tone="var(--red)" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16 }}>
        <Card>
          <div className="sh-display" style={{ fontWeight: 700, marginBottom: 12, fontSize: 15 }}>Average score by quiz</div>
          {perQuiz.length === 0 ? (
            <EmptyState icon={BarChart3} title="No data yet" body="Create and publish a quiz to see analytics." />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={perQuiz}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" fontSize={11} stroke="var(--text-faint)" />
                <YAxis fontSize={11} stroke="var(--text-faint)" domain={[0, 100]} />
                <Tooltip />
                <Bar dataKey="avg" fill="#1f4d3f" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>
        <Card>
          <div className="sh-display" style={{ fontWeight: 700, marginBottom: 12, fontSize: 15 }}>Quiz status</div>
          {quizzes.length === 0 ? (
            <EmptyState icon={Sparkles} title="Nothing yet" body="Your first quiz will show up here." />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
                  {pieData.map((d, i) => <Cell key={i} fill={d.color} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      <Card style={{ marginTop: 16 }}>
        <div className="sh-display" style={{ fontWeight: 700, marginBottom: 10, fontSize: 15 }}>Latest announcements</div>
        {announcements.length === 0 ? (
          <EmptyState icon={Megaphone} title="Quiet in here" body="Post something for your students." />
        ) : (
          announcements.slice(0, 3).map((a) => (
            <div key={a.id} style={{ padding: "10px 0", borderBottom: "1px solid var(--border)" }}>
              <div style={{ fontWeight: 700, fontSize: 13.5 }}>{a.title}</div>
              <div style={{ fontSize: 12.5, color: "var(--text-faint)" }}>{new Date(a.createdAt).toLocaleDateString()}</div>
            </div>
          ))
        )}
      </Card>
    </div>
  );
}
