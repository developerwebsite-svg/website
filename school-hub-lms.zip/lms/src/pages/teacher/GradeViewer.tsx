import { useEffect, useState } from "react";
import { FileText } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/contexts/ToastContext";
import { Card, EmptyState, Pill, SkeletonList } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { listSubmissionsForTeacher, updateSubmissionScore } from "@/api/submissions";
import type { Submission } from "@/types";

export default function GradeViewer() {
  const { profile } = useAuth();
  const { pushToast } = useToast();
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    listSubmissionsForTeacher(profile.id).then(setSubmissions).finally(() => setLoading(false));
  }, [profile]);

  const update = async (id: string, score: number) => {
    setSubmissions((subs) => subs.map((s) => (s.id === id ? { ...s, score: Math.max(0, Math.min(s.total, score)) } : s)));
    try { await updateSubmissionScore(id, score); } catch { pushToast("Couldn't save", "Please try again.", "error"); }
  };

  return (
    <div>
      <PageHeader title="Grade Viewer" subtitle="Review and adjust individual scores." />
      {loading ? (
        <SkeletonList rows={5} />
      ) : (
        <Card style={{ padding: 0, overflow: "hidden" }}>
          {submissions.length === 0 ? (
            <div style={{ padding: 20 }}><EmptyState icon={FileText} title="Nothing to grade" body="Submissions will show up here." /></div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
              <thead>
                <tr style={{ background: "var(--bg-sunken)", textAlign: "left" }}>
                  {["Student", "Exam", "Score", "Percent"].map((h) => (
                    <th key={h} style={{ padding: "10px 16px", fontSize: 11.5, color: "var(--text-faint)", textTransform: "uppercase", fontWeight: 700 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {submissions.map((s) => (
                  <tr key={s.id} style={{ borderTop: "1px solid var(--border)" }}>
                    <td style={{ padding: "10px 16px", fontWeight: 600 }}>{s.studentName}</td>
                    <td style={{ padding: "10px 16px" }}>{s.quizTitle}</td>
                    <td style={{ padding: "8px 16px" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <input
                          type="number"
                          value={s.score}
                          onChange={(e) => update(s.id, Number(e.target.value))}
                          style={{ width: 52, padding: "6px 8px", borderRadius: 8, border: "1.5px solid var(--border)", background: "var(--surface)", color: "var(--text)" }}
                        />
                        <span style={{ color: "var(--text-faint)" }}>/ {s.total}</span>
                      </div>
                    </td>
                    <td style={{ padding: "10px 16px" }}><Pill tone={s.score / s.total >= 0.6 ? "chalk" : "red"}>{Math.round((s.score / s.total) * 100)}%</Pill></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}
    </div>
  );
}
