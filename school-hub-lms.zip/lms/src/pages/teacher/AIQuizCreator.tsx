import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles, AlertTriangle, Trash2, Plus, FileText, Rocket } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/contexts/ToastContext";
import { Card, Button, Input, Select } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { createQuiz } from "@/api/quizzes";
import { EXAM_SUBJECTS } from "@/types";
import type { QuizQuestion } from "@/lib/database.types";

async function generateQuizAI({ topic, subject, difficulty, numQuestions }: { topic: string; subject: string; difficulty: string; numQuestions: number }): Promise<QuizQuestion[]> {
  const apiKey = import.meta.env.VITE_ANTHROPIC_API_KEY;
  if (!apiKey) throw new Error("no-api-key");

  const model = import.meta.env.VITE_ANTHROPIC_MODEL || "claude-sonnet-5";
  const prompt = `Create ${numQuestions} multiple-choice quiz questions for a school exam.
Topic: ${topic}
Subject: ${subject}
Difficulty: ${difficulty}
Respond with ONLY a raw JSON array (no markdown fences, no commentary) in exactly this shape:
[{"question": "string", "options": ["string","string","string","string"], "correctIndex": 0}]
correctIndex is the 0-based index of the correct option.`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({ model, max_tokens: 2000, messages: [{ role: "user", content: prompt }] }),
  });
  if (!response.ok) throw new Error(`Anthropic API error: ${response.status}`);
  const data = await response.json();
  const text = (data.content || []).map((b: any) => b.text || "").join("");
  const clean = text.replace(/```json|```/g, "").trim();
  const parsed = JSON.parse(clean);
  if (!Array.isArray(parsed) || parsed.length === 0) throw new Error("empty");
  return parsed;
}

function localFallbackQuiz(topic: string, n: number): QuizQuestion[] {
  return Array.from({ length: n }, (_, i) => ({
    question: `Sample question ${i + 1} about ${topic || "the topic"}?`,
    options: ["Option A", "Option B", "Option C", "Option D"],
    correctIndex: 0,
  }));
}

const LOADING_MESSAGES = [
  "Reading up on your topic…",
  "Sketching out questions…",
  "Writing answer choices…",
  "Double-checking correct answers…",
  "Tidying up the wording…",
];

export default function AIQuizCreator() {
  const { profile } = useAuth();
  const { pushToast } = useToast();
  const navigate = useNavigate();

  const [topic, setTopic] = useState("");
  const [subject, setSubject] = useState<string>(EXAM_SUBJECTS[0]);
  const [difficulty, setDifficulty] = useState("Medium");
  const [numQuestions, setNumQuestions] = useState(5);
  const [loading, setLoading] = useState(false);
  const [loadingMsgIndex, setLoadingMsgIndex] = useState(0);
  const [error, setError] = useState("");
  const [draft, setDraft] = useState<{ title: string; questions: QuizQuestion[] } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!loading) { setLoadingMsgIndex(0); return; }
    const id = setInterval(() => setLoadingMsgIndex((i) => (i + 1) % LOADING_MESSAGES.length), 1400);
    return () => clearInterval(id);
  }, [loading]);

  const generate = async () => {
    if (!topic.trim()) { setError("Give your exam a topic first."); return; }
    const n = Math.max(1, Math.min(30, Number(numQuestions) || 1));
    setError(""); setLoading(true); setDraft(null);
    try {
      let questions: QuizQuestion[];
      try {
        questions = await generateQuizAI({ topic, subject, difficulty, numQuestions: n });
      } catch {
        questions = localFallbackQuiz(topic, n);
      }
      setDraft({ title: topic, questions });
    } catch {
      setError("Couldn't generate an exam right now. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const updateQuestion = (i: number, field: keyof QuizQuestion, value: any) => {
    setDraft((d) => {
      if (!d) return d;
      const qs = [...d.questions];
      qs[i] = { ...qs[i], [field]: value };
      return { ...d, questions: qs };
    });
  };
  const updateOption = (qi: number, oi: number, value: string) => {
    setDraft((d) => {
      if (!d) return d;
      const qs = [...d.questions];
      const opts = [...qs[qi].options]; opts[oi] = value;
      qs[qi] = { ...qs[qi], options: opts };
      return { ...d, questions: qs };
    });
  };
  const addQuestion = () => setDraft((d) => d && ({ ...d, questions: [...d.questions, { question: "New question", options: ["Option A", "Option B", "Option C", "Option D"], correctIndex: 0 }] }));
  const removeQuestion = (i: number) => setDraft((d) => d && ({ ...d, questions: d.questions.filter((_, idx) => idx !== i) }));

  const save = async (publish: boolean) => {
    if (!draft || !profile) return;
    setSaving(true);
    try {
      await createQuiz({ teacherId: profile.id, title: draft.title, subject, difficulty, questions: draft.questions, published: publish });
      pushToast(publish ? "Exam published!" : "Draft saved", draft.title, "success");
      navigate("/teacher/published");
    } catch (e: any) {
      pushToast("Couldn't save", e.message ?? "Something went wrong.", "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader title="AI Quiz Creator" subtitle="Describe a topic — Claude drafts the questions for you to review." />
      <div style={{ display: "grid", gridTemplateColumns: draft ? "1fr" : "minmax(280px,420px)", gap: 16 }}>
        {!draft && !loading && (
          <Card>
            <Input label="Exam topic" placeholder="e.g. Photosynthesis, The French Revolution…" value={topic} onChange={(e) => setTopic(e.target.value)} />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <Select label="Subject" value={subject} onChange={(e) => setSubject(e.target.value)}>
                {EXAM_SUBJECTS.map((s) => <option key={s}>{s}</option>)}
              </Select>
              <Select label="Difficulty" value={difficulty} onChange={(e) => setDifficulty(e.target.value)}>
                {["Easy", "Medium", "Hard"].map((s) => <option key={s}>{s}</option>)}
              </Select>
            </div>
            <Input label="Number of questions" type="number" min={1} max={30} value={numQuestions} onChange={(e) => setNumQuestions(Number(e.target.value))} />
            {error && <div style={{ color: "var(--red)", fontSize: 13, marginBottom: 10, display: "flex", gap: 6, alignItems: "center" }}><AlertTriangle size={14} />{error}</div>}
            <Button icon={Sparkles} onClick={generate} full>Generate exam</Button>
          </Card>
        )}

        {loading && (
          <Card style={{ textAlign: "center", padding: "34px 24px" }}>
            <span className="sh-spin" style={{ color: "var(--chalk)", display: "inline-flex", marginBottom: 14 }}><Sparkles size={32} /></span>
            <div className="sh-display" style={{ fontWeight: 700, fontSize: 16, marginBottom: 4 }}>Generating your exam</div>
            <div style={{ fontSize: 13, color: "var(--text-faint)", minHeight: 18, marginBottom: 18 }}>{LOADING_MESSAGES[loadingMsgIndex]}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="sh-shimmer" style={{ height: 12, width: i === 3 ? "60%" : "100%" }} />
              ))}
            </div>
          </Card>
        )}

        {draft && (
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: "var(--text-faint)", textTransform: "uppercase", marginBottom: 4 }}>Review & edit</div>
                <input value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} className="sh-display" style={{ fontSize: 20, fontWeight: 700, border: "none", background: "transparent", outline: "none", color: "var(--text)" }} />
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <Button variant="ghost" onClick={() => setDraft(null)}>Discard</Button>
                <Button variant="gold" icon={FileText} disabled={saving} onClick={() => save(false)}>Save draft</Button>
                <Button variant="primary" icon={Rocket} disabled={saving} onClick={() => save(true)}>Publish</Button>
              </div>
            </div>

            {draft.questions.map((q, qi) => (
              <div key={qi} style={{ padding: "14px 0", borderTop: "1px solid var(--border)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: "var(--chalk)" }}>QUESTION {qi + 1}</div>
                  <button onClick={() => removeQuestion(qi)} style={{ background: "none", border: "none", color: "var(--red)", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, fontSize: 11.5, fontWeight: 700 }}><Trash2 size={13} /> Remove</button>
                </div>
                <input value={q.question} onChange={(e) => updateQuestion(qi, "question", e.target.value)} style={{ width: "100%", fontWeight: 600, fontSize: 14.5, border: "none", outline: "none", background: "transparent", marginBottom: 10, color: "var(--text)" }} />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                  {q.options.map((opt, oi) => (
                    <label key={oi} style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 10px", borderRadius: 9, border: `1.5px solid ${q.correctIndex === oi ? "var(--chalk)" : "var(--border)"}`, background: q.correctIndex === oi ? "color-mix(in srgb, var(--chalk) 12%, transparent)" : "var(--surface)" }}>
                      <input type="radio" checked={q.correctIndex === oi} onChange={() => updateQuestion(qi, "correctIndex", oi)} />
                      <input value={opt} onChange={(e) => updateOption(qi, oi, e.target.value)} style={{ border: "none", outline: "none", background: "transparent", fontSize: 13.5, flex: 1, color: "var(--text)" }} />
                    </label>
                  ))}
                </div>
              </div>
            ))}
            <div style={{ paddingTop: 14 }}>
              <Button size="sm" variant="ghost" icon={Plus} onClick={addQuestion}>Add question</Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
