import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { listSubmissionsForTeacher } from "@/api/submissions";
import { LeaderboardView } from "@/components/LeaderboardView";
import { SkeletonList } from "@/components/ui";
import type { Submission } from "@/types";

export default function TeacherLeaderboard() {
  const { profile } = useAuth();
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;
    listSubmissionsForTeacher(profile.id).then(setSubmissions).finally(() => setLoading(false));
  }, [profile]);

  if (loading) return <SkeletonList rows={5} />;
  return <LeaderboardView submissions={submissions} />;
}
