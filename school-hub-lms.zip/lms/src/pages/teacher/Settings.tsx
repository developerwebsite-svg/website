import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/contexts/ToastContext";
import { supabase } from "@/lib/supabaseClient";
import { Card, Button, Input } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";

export default function TeacherSettings() {
  const { profile } = useAuth();
  const { pushToast } = useToast();
  const [fullName, setFullName] = useState(profile?.fullName ?? "");
  const [className, setClassName] = useState("");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    if (!profile) return;
    setSaving(true);
    try {
      await supabase.from("users").update({ full_name: fullName }).eq("id", profile.id);
      if (className.trim()) await supabase.from("teachers").upsert({ user_id: profile.id, class_name: className });
      pushToast("Saved", "Your profile was updated.", "success");
    } catch {
      pushToast("Couldn't save", "Please try again.", "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <PageHeader title="Settings" subtitle="Your profile info." />
      <Card style={{ maxWidth: 420 }}>
        <Input label="Full name" value={fullName} onChange={(e) => setFullName(e.target.value)} />
        <Input label="Class name" value={className} onChange={(e) => setClassName(e.target.value)} placeholder="e.g. Period 3 · Biology" />
        <Input label="Email" value={profile?.email ?? ""} disabled />
        <Button disabled={saving} onClick={save}>{saving ? "Saving…" : "Save changes"}</Button>
      </Card>
    </div>
  );
}
