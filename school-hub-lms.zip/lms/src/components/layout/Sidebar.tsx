import { NavLink } from "react-router-dom";
import { GraduationCap } from "lucide-react";
import type { Role } from "@/types";

export interface NavTab {
  to: string;
  label: string;
  icon: React.ElementType;
  badge?: boolean;
}

export function Sidebar({ role, tabs }: { role: Role; tabs: NavTab[] }) {
  return (
    <div
      className="app-sidebar"
      style={{
        width: 232,
        minHeight: "100vh",
        background: "var(--sidebar-bg)",
        color: "var(--sidebar-text)",
        display: "flex",
        flexDirection: "column",
        position: "sticky",
        top: 0,
        flexShrink: 0,
        zIndex: 30,
        transition: "background-color .25s ease",
      }}
    >
      <div className="sidebar-head" style={{ padding: "22px 18px 14px 26px", borderBottom: "1px dashed rgba(255,255,255,.15)" }}>
        <div className="sh-display" style={{ fontWeight: 700, fontSize: 18, display: "flex", alignItems: "center", gap: 8 }}>
          <GraduationCap size={20} style={{ color: "var(--gold)" }} /> School Hub
        </div>
        <div className="sh-hand hide-mobile" style={{ fontSize: 13, color: "var(--sidebar-text-muted)", marginTop: 2 }}>
          {role === "teacher" ? "teacher mode" : "student mode"}
        </div>
      </div>

      <div className="sidebar-tabs" style={{ flex: 1, padding: "10px 10px 10px 20px", display: "flex", flexDirection: "column", gap: 3, overflowY: "auto" }}>
        {tabs.map((t) => (
          <NavLink
            key={t.to}
            to={t.to}
            end
            className="sidebar-tab"
            style={({ isActive }) => ({
              display: "flex",
              alignItems: "center",
              gap: 11,
              padding: "10px 12px",
              borderRadius: "10px 3px 3px 10px",
              textDecoration: "none",
              fontSize: 14,
              fontWeight: isActive ? 700 : 500,
              background: isActive ? "var(--surface)" : "transparent",
              color: isActive ? "var(--text)" : "var(--sidebar-text)",
              boxShadow: isActive ? "0 3px 10px -4px rgba(0,0,0,.4)" : "none",
              transition: "all .12s ease",
              whiteSpace: "nowrap",
              flexShrink: 0,
              position: "relative",
            })}
          >
            <t.icon size={16} style={{ flexShrink: 0 }} />
            {t.label}
            {t.badge && <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--red)", marginLeft: 2 }} />}
          </NavLink>
        ))}
      </div>
    </div>
  );
}
