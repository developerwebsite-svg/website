import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import type { Role } from "@/types";
import { FullScreenLoader } from "@/components/layout/FullScreenLoader";

export function ProtectedRoute({ role, children }: { role: Role; children: React.ReactNode }) {
  const { session, profile, loading } = useAuth();

  if (loading) return <FullScreenLoader label="Loading your account…" />;
  if (!session) return <Navigate to="/" replace />;
  if (!profile) return <FullScreenLoader label="Setting up your profile…" />;
  if (profile.role !== role) return <Navigate to={`/${profile.role}`} replace />;

  return <>{children}</>;
}
