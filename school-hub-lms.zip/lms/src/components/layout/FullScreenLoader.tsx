import { motion } from "framer-motion";
import { GraduationCap } from "lucide-react";

export function FullScreenLoader({ label = "Loading…" }: { label?: string }) {
  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, background: "var(--bg)", color: "var(--text)" }}>
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ repeat: Infinity, duration: 1.1, ease: "linear" }}
        style={{ color: "var(--chalk)" }}
      >
        <GraduationCap size={34} />
      </motion.div>
      <div style={{ fontSize: 13.5, color: "var(--text-muted)" }}>{label}</div>
    </div>
  );
}
