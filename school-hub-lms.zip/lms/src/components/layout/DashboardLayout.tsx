import { Outlet, useNavigate } from "react-router-dom";
import {
  Home, Sparkles, ClipboardList, Users, FileText, Calculator, Trophy,
  Megaphone, Settings, PlayCircle, Award, LogOut, Lock,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/contexts/ToastContext";
import { Sidebar, type NavTab } from "./Sidebar";
import { ThemeToggle } from "@/components/theme/ThemeToggle";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { formatMMSS } from "@/hooks/useNow";
import { useNotifications } from "@/hooks/useNotifications";

const TEACHER_TABS: NavTab[] = [
  { to: "/teacher", label: "Dashboard", icon: Home },
  { to: "/teacher/creator", label: "AI Quiz Creator", icon: Sparkles },
  { to: "/teacher/published", label: "Published Quizzes", icon: ClipboardList },
  { to: "/teacher/results", label: "Student Results", icon: Users },
  { to: "/teacher/grades", label: "Grade Viewer", icon: FileText },
  { to: "/teacher/calculator", label: "Grade Calculator", icon: Calculator },
  { to: "/teacher/leaderboard", label: "Leaderboard", icon: Trophy },
  { to: "/teacher/announcements", label: "Announcements", icon: Megaphone },
  { to: "/teacher/settings", label: "Settings", icon: Settings },
];

const STUDENT_TABS: NavTab[] = [
  { to: "/student", label: "Home", icon: Home },
  { to: "/student/join", label: "Join Exam", icon: PlayCircle },
  { to: "/student/grades", label: "My Grades", icon: Award },
  { to: "/student/leaderboard", label: "Leaderboard", icon: Trophy },
  { to: "/student/announcements", label: "Announcements", icon: Megaphone },
];

export function DashboardLayout({ role }: { role: "teacher" | "student" }) {
  const { profile, signOut, logoutLocked, logoutRemainingMs } = useAuth();
  const { pushToast } = useToast();
  const { unseenAnnouncement } = useUnseenAnnouncementFlag();
  const navigate = useNavigate();

  const tabs = (role === "teacher" ? TEACHER_TABS : STUDENT_TABS).map((t) =>
    t.to.endsWith("/announcements") ? { ...t, badge: unseenAnnouncement } : t
  );

  const handleLogout = async () => {
    if (logoutLocked) {
      pushToast("Hold on!", `You can log out again in ${formatMMSS(logoutRemainingMs)}.`);
      return;
    }
    await signOut();
    navigate("/");
  };

  return (
    <div className="app-shell">
      <Sidebar role={role} tabs={tabs} />
      <div className="app-content" style={{ padding: 0 }}>
        <div
          style={{
            display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12,
            padding: "14px 24px", borderBottom: "1px solid var(--border)", position: "sticky", top: 0,
            background: "var(--bg-elevated)", zIndex: 20, flexWrap: "wrap",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: "50%", background: "var(--chalk)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 14 }}>
              {profile?.fullName?.charAt(0)?.toUpperCase() ?? "?"}
            </div>
            <div>
              <div style={{ fontSize: 13.5, fontWeight: 700 }}>{profile?.fullName ?? "…"}</div>
              <div style={{ fontSize: 11, color: "var(--text-faint)", textTransform: "capitalize" }}>{role}</div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <ThemeToggle />
            <NotificationBell />
            <button
              onClick={handleLogout}
              title={logoutLocked ? `You can log out in ${formatMMSS(logoutRemainingMs)}` : "Log out"}
              style={{
                display: "flex", alignItems: "center", gap: 6, padding: "9px 13px", borderRadius: 10,
                border: "1px solid var(--border)", background: "var(--surface)", color: logoutLocked ? "var(--text-faint)" : "var(--text)",
                fontSize: 12.5, fontWeight: 600, cursor: logoutLocked ? "not-allowed" : "pointer",
              }}
            >
              {logoutLocked ? <Lock size={13} /> : <LogOut size={13} />}
              {logoutLocked ? formatMMSS(logoutRemainingMs) : "Log out"}
            </button>
          </div>
        </div>
        <div style={{ padding: "28px 32px" }} className="app-content">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

/** Small helper so the sidebar can show a red dot on Announcements when there's
 *  something the user hasn't opened that tab to see yet. Kept intentionally
 *  simple (session-only) rather than persisting per-user "last seen" state. */
function useUnseenAnnouncementFlag() {
  const { notifications } = useNotifications();
  const unseenAnnouncement = notifications.some((n) => n.category === "announcement" && !n.read);
  return { unseenAnnouncement };
}
