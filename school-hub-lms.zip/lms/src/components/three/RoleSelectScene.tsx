import React, { useCallback, useEffect, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Float, RoundedBox, Html, Sparkles } from "@react-three/drei";
import * as THREE from "three";
import { motion, AnimatePresence } from "framer-motion";
import type { Role } from "@/types";

interface CardDef {
  role: Role;
  label: string;
  sub: string;
  emoji: string;
  color: string;
  position: [number, number, number];
}

function useIsNarrow() {
  const [narrow, setNarrow] = useState(() => (typeof window !== "undefined" ? window.innerWidth < 720 : false));
  useEffect(() => {
    const onResize = () => setNarrow(window.innerWidth < 720);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);
  return narrow;
}

/** Smoothly moves the camera toward a target on select, gentle idle sway otherwise. */
function CameraRig({ zoomTarget }: { zoomTarget: [number, number, number] | null }) {
  useFrame((state, delta) => {
    const cam = state.camera;
    if (zoomTarget) {
      const dest = new THREE.Vector3(zoomTarget[0] * 0.35, zoomTarget[1] * 0.35, zoomTarget[2] + 2.6);
      cam.position.lerp(dest, 1 - Math.pow(0.001, delta));
      cam.lookAt(zoomTarget[0] * 0.3, zoomTarget[1], 0);
    } else {
      cam.position.x = THREE.MathUtils.lerp(cam.position.x, Math.sin(state.clock.elapsedTime * 0.15) * 0.5, delta * 1.2);
      cam.position.y = THREE.MathUtils.lerp(cam.position.y, 0.3 + Math.cos(state.clock.elapsedTime * 0.12) * 0.2, delta * 1.2);
      cam.lookAt(0, 0.2, 0);
    }
  });
  return null;
}

function RoleCard3D({
  def,
  disabled,
  onHover,
  onClick,
}: {
  def: CardDef;
  disabled: boolean;
  onHover: (role: Role | null) => void;
  onClick: (role: Role) => void;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((_, delta) => {
    const m = meshRef.current;
    if (!m) return;
    const targetScale = hovered && !disabled ? 1.12 : 1;
    m.scale.lerp(new THREE.Vector3(targetScale, targetScale, targetScale), 1 - Math.pow(0.001, delta));
    if (hovered && !disabled) {
      m.rotation.y += delta * 0.7;
    } else {
      m.rotation.y = THREE.MathUtils.lerp(m.rotation.y, 0, 1 - Math.pow(0.01, delta));
    }
    const mat = m.material as THREE.MeshStandardMaterial;
    if (mat) mat.emissiveIntensity = THREE.MathUtils.lerp(mat.emissiveIntensity, hovered && !disabled ? 0.75 : 0.18, 1 - Math.pow(0.001, delta));
  });

  return (
    <Float speed={1.4} rotationIntensity={0.35} floatIntensity={0.8}>
      <group position={def.position}>
        <RoundedBox
          ref={meshRef as any}
          args={[2.15, 2.75, 0.18]}
          radius={0.16}
          smoothness={4}
          onPointerOver={(e) => { e.stopPropagation(); if (disabled) return; setHovered(true); onHover(def.role); document.body.style.cursor = "pointer"; }}
          onPointerOut={(e) => { e.stopPropagation(); setHovered(false); onHover(null); document.body.style.cursor = "auto"; }}
          onClick={(e) => { e.stopPropagation(); if (!disabled) onClick(def.role); }}
        >
          <meshStandardMaterial color={def.color} emissive={def.color} emissiveIntensity={0.18} roughness={0.35} metalness={0.15} />
        </RoundedBox>
        <Html center distanceFactor={7.2} position={[0, 0, 0.11]} style={{ pointerEvents: "none", textAlign: "center", width: 180 }}>
          <div style={{ fontSize: 46, marginBottom: 4 }}>{def.emoji}</div>
          <div style={{ fontWeight: 700, fontFamily: "'Space Grotesk', sans-serif", fontSize: 17, color: "#fff", textShadow: "0 2px 8px rgba(0,0,0,.4)" }}>{def.label}</div>
          <div style={{ fontSize: 11.5, color: "rgba(255,255,255,.75)", marginTop: 2 }}>{def.sub}</div>
        </Html>
      </group>
    </Float>
  );
}

function Scene({ narrow, selected, onHover, onClick }: { narrow: boolean; selected: Role | null; onHover: (r: Role | null) => void; onClick: (r: Role) => void }) {
  const spread = narrow ? 1.55 : 2.5;
  const cards: CardDef[] = [
    { role: "teacher", label: "Teacher", sub: "Run the classroom", emoji: "👨‍🏫", color: "#d9a441", position: [-spread, 0, 0] },
    { role: "student", label: "Student", sub: "Join & learn", emoji: "👨‍🎓", color: "#4f8fd6", position: [spread, 0, 0] },
  ];
  const zoomTarget = selected ? cards.find((c) => c.role === selected)?.position ?? null : null;

  return (
    <>
      <ambientLight intensity={0.55} />
      <pointLight position={[4, 4, 6]} intensity={60} color="#ffffff" />
      <pointLight position={[-4, -2, 4]} intensity={30} color="#d9a441" />
      <Sparkles count={140} scale={[10, 6, 6]} size={2.2} speed={0.28} color="#e8dcb8" opacity={0.55} />
      {cards.map((c) => (
        <RoleCard3D key={c.role} def={c} disabled={selected !== null && selected !== c.role} onHover={onHover} onClick={onClick} />
      ))}
      <CameraRig zoomTarget={zoomTarget as [number, number, number] | null} />
    </>
  );
}

export function RoleSelectScene({ onSelect }: { onSelect: (role: Role) => void }) {
  const narrow = useIsNarrow();
  const [hovered, setHovered] = useState<Role | null>(null);
  const [selected, setSelected] = useState<Role | null>(null);

  const handleClick = useCallback(
    (role: Role) => {
      if (selected) return;
      setSelected(role);
      // Give the camera zoom + fade time to play before actually navigating.
      setTimeout(() => onSelect(role), 1150);
    },
    [selected, onSelect]
  );

  return (
    <div style={{ position: "relative", width: "100%", height: "100vh", background: "radial-gradient(circle at 30% 20%, #234a3c 0%, #0d211a 60%, #081512 100%)", overflow: "hidden" }}>
      <Canvas
        camera={{ position: [0, 0.3, 8.5], fov: 45 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, powerPreference: "high-performance" }}
        style={{ touchAction: "none" }}
      >
        <React.Suspense fallback={null}>
          <Scene narrow={narrow} selected={selected} onHover={setHovered} onClick={handleClick} />
        </React.Suspense>
      </Canvas>

      {/* HTML overlay: title + hint text, fades out on selection */}
      <AnimatePresence>
        {!selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: { duration: 0.5 } }}
            style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", pointerEvents: "none", padding: "8vh 20px 0" }}
          >
            <div className="sh-hand" style={{ color: "#eadfc0", fontSize: 20, marginBottom: 2 }}>welcome to the</div>
            <div className="sh-display" style={{ color: "#fbf9f1", fontSize: "clamp(30px,6vw,52px)", fontWeight: 700, letterSpacing: -1, marginBottom: 8, display: "flex", alignItems: "center", gap: 10 }}>
              🎓 School Hub
            </div>
            <div style={{ color: "#c9dccf", fontSize: 14.5, textAlign: "center", maxWidth: 380 }}>
              {hovered ? `Tap to continue as ${hovered === "teacher" ? "Teacher" : "Student"}` : "Tap a card to get started"}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Full fade-to-chalkboard as the camera finishes zooming in */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.55, duration: 0.55 }}
            style={{ position: "absolute", inset: 0, background: "#0d211a", pointerEvents: "none" }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
