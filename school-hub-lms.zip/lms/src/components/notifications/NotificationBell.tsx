import { useRef, useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Bell, Trash2, ClipboardList, Megaphone, Award, CalendarCheck, BookOpen } from "lucide-react";
import { useNotifications } from "@/hooks/useNotifications";
import { EmptyState } from "@/components/ui";
import type { AppNotification, NotificationCategory } from "@/types";

const CATEGORY_META: Record<NotificationCategory, { icon: React.ElementType; color: string; label: string }> = {
  assignment: { icon: ClipboardList, color: "var(--blue)", label: "Assignment" },
  quiz: { icon: BookOpen, color: "var(--chalk)", label: "Quiz" },
  announcement: { icon: Megaphone, color: "var(--gold)", label: "Announcement" },
  grade: { icon: Award, color: "var(--red)", label: "Grade" },
  attendance: { icon: CalendarCheck, color: "var(--blue)", label: "Attendance" },
};

function timeAgo(iso: string) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

function NotificationItem({ n, onRead, onDelete }: { n: AppNotification; onRead: (id: string) => void; onDelete: (id: string) => void }) {
  const meta = CATEGORY_META[n.category];
  const Icon = meta.icon;
  return (
    <div
      onClick={() => !n.read && onRead(n.id)}
      style={{
        display: "flex",
        gap: 10,
        padding: "10px 14px",
        borderBottom: "1px solid var(--border)",
        cursor: n.read ? "default" : "pointer",
        background: n.read ? "transparent" : "color-mix(in srgb, var(--chalk) 6%, transparent)",
      }}
    >
      <div style={{ width: 30, height: 30, borderRadius: 9, background: `color-mix(in srgb, ${meta.color} 18%, transparent)`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <Icon size={15} style={{ color: meta.color }} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 6 }}>
          <span style={{ fontWeight: 700, fontSize: 12.5 }}>{n.title}</span>
          {!n.read && <span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--red)", flexShrink: 0, marginTop: 4 }} />}
        </div>
        {n.body && <div style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>{n.body}</div>}
        <div style={{ fontSize: 10.5, color: "var(--text-faint)", marginTop: 4 }}>{meta.label} · {timeAgo(n.createdAt)}</div>
      </div>
      <button
        onClick={(e) => { e.stopPropagation(); onDelete(n.id); }}
        style={{ background: "none", border: "none", color: "var(--text-faint)", cursor: "pointer", alignSelf: "flex-start" }}
        aria-label="Delete notification"
      >
        <Trash2 size={14} />
      </button>
    </div>
  );
}

export function NotificationBell() {
  const { notifications, unreadCount, markRead, markAllRead, remove } = useNotifications();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label="Notifications"
        style={{
          position: "relative", width: 38, height: 38, borderRadius: "50%", border: "1px solid var(--border)",
          background: "var(--surface)", color: "var(--text)", display: "flex", alignItems: "center", justifyContent: "center",
          cursor: "pointer", touchAction: "manipulation",
        }}
      >
        <Bell size={17} />
        {unreadCount > 0 && (
          <span style={{
            position: "absolute", top: -3, right: -3, minWidth: 17, height: 17, padding: "0 4px", borderRadius: 999,
            background: "var(--red)", color: "#fff", fontSize: 10, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.97 }}
            transition={{ duration: 0.18 }}
            className="card-surface"
            style={{ position: "absolute", right: 0, top: 46, width: 320, maxWidth: "90vw", maxHeight: 420, overflow: "hidden", zIndex: 120, display: "flex", flexDirection: "column" }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 14px", borderBottom: "1px solid var(--border)" }}>
              <span className="sh-display" style={{ fontWeight: 700, fontSize: 14 }}>Notifications</span>
              {unreadCount > 0 && (
                <button onClick={markAllRead} style={{ background: "none", border: "none", color: "var(--blue)", fontSize: 11.5, fontWeight: 700, cursor: "pointer" }}>
                  Mark all read
                </button>
              )}
            </div>
            <div style={{ overflowY: "auto" }}>
              {notifications.length === 0 ? (
                <div style={{ padding: "12px 0" }}>
                  <EmptyState icon={Bell} title="You're all caught up" body="New assignments, quizzes, and announcements will show up here." />
                </div>
              ) : (
                notifications.map((n) => <NotificationItem key={n.id} n={n} onRead={markRead} onDelete={remove} />)
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
