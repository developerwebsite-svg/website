import { Mail } from "lucide-react";

export function ProviderMark({ provider }: { provider: "google" | "facebook" | "email" }) {
  if (provider === "google") {
    return (
      <div style={{ width: 22, height: 22, borderRadius: "50%", background: "conic-gradient(#EA4335 0deg 90deg,#FBBC05 90deg 180deg,#34A853 180deg 270deg,#4285F4 270deg 360deg)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <div style={{ width: 13, height: 13, borderRadius: "50%", background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, color: "#4285F4" }}>G</div>
      </div>
    );
  }
  if (provider === "facebook") {
    return (
      <div style={{ width: 22, height: 22, borderRadius: "50%", background: "#1877F2", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, color: "#fff", fontWeight: 800, fontSize: 13, fontFamily: "Georgia, serif" }}>f</div>
    );
  }
  return (
    <div style={{ width: 22, height: 22, borderRadius: "50%", background: "var(--chalk)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <Mail size={12} color="#fff" />
    </div>
  );
}

export function ProviderButton({ provider, onClick, children }: { provider: "google" | "facebook" | "email"; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      style={{
        display: "flex", alignItems: "center", gap: 12, width: "100%", padding: "11px 14px",
        borderRadius: 12, border: "1.5px solid var(--border)", background: "var(--surface)", cursor: "pointer",
        fontSize: 14, fontWeight: 600, color: "var(--text)", touchAction: "manipulation",
      }}
    >
      <ProviderMark provider={provider} /> {children}
    </button>
  );
}
