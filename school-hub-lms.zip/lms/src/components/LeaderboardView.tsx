import { useMemo } from "react";
import { motion } from "framer-motion";
import { Trophy, Medal } from "lucide-react";
import { Card, EmptyState, Pill } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import type { Submission } from "@/types";

export function LeaderboardView({ submissions }: { submissions: Submission[] }) {
  const board = useMemo(() => {
    const byStudent: Record<string, { name: string; section: string | null; pct: number }> = {};
    submissions.forEach((s) => {
      const pct = (s.score / s.total) * 100;
      if (!byStudent[s.studentName] || byStudent[s.studentName].pct < pct) {
        byStudent[s.studentName] = { name: s.studentName, section: s.section, pct };
      }
    });
    return Object.values(byStudent).sort((a, b) => b.pct - a.pct);
  }, [submissions]);

  const medalColor = (i: number) => (i === 0 ? "var(--gold)" : i === 1 ? "#b7b7b7" : i === 2 ? "#c17a4a" : null);

  return (
    <div>
      <PageHeader title="Leaderboard" subtitle="Ranked by best exam percentage." />
      {board.length === 0 ? (
        <Card><EmptyState icon={Trophy} title="No rankings yet" body="Scores will populate this board as exams are submitted." /></Card>
      ) : (
        <>
          <div style={{ display: "flex", gap: 14, justifyContent: "center", marginBottom: 24, flexWrap: "wrap" }}>
            {board.slice(0, 3).map((b, i) => (
              <motion.div
                key={b.name}
                whileHover={{ scale: 1.05, rotate: i === 0 ? 0 : i % 2 === 0 ? -2 : 2 }}
                style={{
                  width: 150, textAlign: "center", padding: "20px 14px", borderRadius: 16, background: "var(--surface)",
                  borderTop: `5px solid ${medalColor(i)}`, boxShadow: `0 3px 0 ${medalColor(i)}, 0 16px 30px -16px var(--shadow-color)`,
                  transform: i === 0 ? "translateY(-10px)" : "none",
                }}
              >
                <Medal size={26} style={{ color: medalColor(i) ?? undefined, marginBottom: 6 }} />
                <div className="sh-display" style={{ fontWeight: 700, fontSize: 15 }}>{b.name}</div>
                <div style={{ fontSize: 11.5, color: "var(--text-faint)", marginBottom: 6 }}>{b.section ?? "—"}</div>
                <div style={{ fontSize: 20, fontWeight: 700, color: "var(--chalk)" }}>{Math.round(b.pct)}%</div>
              </motion.div>
            ))}
          </div>
          <Card style={{ padding: 0, overflow: "hidden" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
              <thead>
                <tr style={{ background: "var(--bg-sunken)", textAlign: "left" }}>
                  {["Rank", "Student", "Section", "Best score"].map((h) => (
                    <th key={h} style={{ padding: "10px 16px", fontSize: 11.5, color: "var(--text-faint)", textTransform: "uppercase", fontWeight: 700 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {board.map((b, i) => (
                  <tr key={b.name} style={{ borderTop: "1px solid var(--border)" }}>
                    <td style={{ padding: "9px 16px", fontWeight: 700, color: medalColor(i) ?? "var(--text)" }}>#{i + 1}</td>
                    <td style={{ padding: "9px 16px", fontWeight: 600 }}>{b.name}</td>
                    <td style={{ padding: "9px 16px" }}>{b.section ?? "—"}</td>
                    <td style={{ padding: "9px 16px" }}><Pill tone="chalk">{Math.round(b.pct)}%</Pill></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        </>
      )}
    </div>
  );
}
