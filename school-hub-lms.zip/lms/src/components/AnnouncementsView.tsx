import { useEffect, useState } from "react";
import { Megaphone, Plus, Trash2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/contexts/ToastContext";
import { Card, Button, Modal, Input, Textarea, EmptyState, SkeletonList } from "@/components/ui";
import { PageHeader } from "@/components/PageHeader";
import { listAnnouncements, postAnnouncement, deleteAnnouncement } from "@/api/announcements";
import type { Announcement } from "@/types";

export function AnnouncementsView({ editable }: { editable: boolean }) {
  const { profile } = useAuth();
  const { pushToast } = useToast();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    listAnnouncements().then(setAnnouncements).finally(() => setLoading(false));
  }, []);

  const post = async () => {
    if (!title.trim() || !profile) return;
    setPosting(true);
    try {
      const created = await postAnnouncement({ authorId: profile.id, authorName: profile.fullName, title, body });
      setAnnouncements((a) => [created, ...a]);
      pushToast("Posted!", title, "success");
      setModal(false); setTitle(""); setBody("");
    } catch {
      pushToast("Couldn't post", "Please try again.", "error");
    } finally {
      setPosting(false);
    }
  };

  const remove = async (id: string) => {
    setAnnouncements((a) => a.filter((x) => x.id !== id));
    try { await deleteAnnouncement(id); } catch { pushToast("Couldn't delete", "Please try again.", "error"); }
  };

  return (
    <div>
      <PageHeader
        title="Announcements"
        subtitle="Updates for the whole class."
        right={editable && <Button size="sm" icon={Plus} onClick={() => setModal(true)}>New announcement</Button>}
      />
      {loading ? (
        <SkeletonList rows={3} />
      ) : announcements.length === 0 ? (
        <Card><EmptyState icon={Megaphone} title="Nothing posted yet" body="Announcements will appear here for everyone to see." /></Card>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {announcements.map((a) => (
            <Card key={a.id} style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
              <div style={{ display: "flex", gap: 12 }}>
                <div style={{ width: 36, height: 36, borderRadius: 10, background: "color-mix(in srgb, var(--gold) 22%, transparent)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <Megaphone size={17} style={{ color: "#8a5f10" }} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14.5 }}>{a.title}</div>
                  {a.body && <div style={{ fontSize: 13, color: "var(--text-muted)", margin: "4px 0" }}>{a.body}</div>}
                  <div style={{ fontSize: 11.5, color: "var(--text-faint)" }}>{new Date(a.createdAt).toLocaleString()} · {a.authorName}</div>
                </div>
              </div>
              {editable && <button onClick={() => remove(a.id)} style={{ background: "none", border: "none", color: "var(--red)", cursor: "pointer" }}><Trash2 size={16} /></button>}
            </Card>
          ))}
        </div>
      )}
      <Modal open={modal} onClose={() => setModal(false)} title="New announcement">
        <Input label="Title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Field trip permission slips due Friday" />
        <Textarea label="Details" rows={4} value={body} onChange={(e) => setBody(e.target.value)} />
        <Button full icon={Megaphone} disabled={posting} onClick={post}>{posting ? "Posting…" : "Post announcement"}</Button>
      </Modal>
    </div>
  );
}
