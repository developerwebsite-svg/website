import React, { useState } from "react";
import { motion } from "framer-motion";
import { X } from "lucide-react";
import clsx from "clsx";

/* ---------------- Button ---------------- */
type ButtonVariant = "primary" | "danger" | "gold" | "ghost" | "blue";

interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "size"> {
  variant?: ButtonVariant;
  size?: "sm" | "md" | "lg";
  icon?: React.ElementType;
  full?: boolean;
}

const PALETTES: Record<ButtonVariant, { bg: string; fg: string; shadow: string }> = {
  primary: { bg: "var(--chalk)", fg: "#fff", shadow: "#123326" },
  danger: { bg: "var(--red)", fg: "#fff", shadow: "#8f2c23" },
  gold: { bg: "var(--gold)", fg: "#2b2107", shadow: "#a9791f" },
  ghost: { bg: "var(--surface)", fg: "var(--text)", shadow: "var(--border)" },
  blue: { bg: "var(--blue)", fg: "#fff", shadow: "#274d78" },
};

export function Button({ children, variant = "primary", size = "md", icon: Icon, full, disabled, className, ...rest }: ButtonProps) {
  const [pressed, setPressed] = useState(false);
  const p = PALETTES[variant];
  const pad = size === "sm" ? "7px 12px" : size === "lg" ? "14px 22px" : "10px 16px";
  return (
    <button
      {...rest}
      disabled={disabled}
      className={clsx(className)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        width: full ? "100%" : undefined,
        padding: pad,
        borderRadius: 12,
        border: "none",
        cursor: disabled ? "not-allowed" : "pointer",
        background: p.bg,
        color: p.fg,
        fontWeight: 600,
        fontSize: size === "sm" ? 13 : 14.5,
        boxShadow: disabled ? "none" : pressed ? `0 1px 0 ${p.shadow}` : `0 4px 0 ${p.shadow}`,
        opacity: disabled ? 0.55 : 1,
        transform: pressed && !disabled ? "translateY(3px)" : "translateY(0)",
        transition: "transform .08s ease, box-shadow .08s ease, background-color .2s ease",
        whiteSpace: "nowrap",
        touchAction: "manipulation",
        WebkitTapHighlightColor: "transparent",
        userSelect: "none",
      }}
      onPointerDown={() => !disabled && setPressed(true)}
      onPointerUp={() => setPressed(false)}
      onPointerLeave={() => setPressed(false)}
      onPointerCancel={() => setPressed(false)}
    >
      {Icon && <Icon size={size === "sm" ? 14 : 17} style={{ flexShrink: 0 }} />}
      {children}
    </button>
  );
}

/* ---------------- Card ---------------- */
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  glass?: boolean;
  animate?: boolean;
}
export function Card({ children, style, className, glass, animate = true, ...rest }: CardProps) {
  const Comp: any = animate ? motion.div : "div";
  const motionProps = animate ? { initial: { opacity: 0, y: 14 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.35 } } : {};
  return (
    <Comp
      {...rest}
      {...motionProps}
      className={clsx(glass ? "glass-card" : "card-surface", className)}
      style={{ padding: 20, ...style }}
    >
      {children}
    </Comp>
  );
}

/* ---------------- Pill / Badge ---------------- */
type PillTone = "chalk" | "gold" | "red" | "blue";
const PILL_TONES: Record<PillTone, { bg: string; fg: string }> = {
  chalk: { bg: "color-mix(in srgb, var(--chalk) 16%, transparent)", fg: "var(--chalk-light)" },
  gold: { bg: "color-mix(in srgb, var(--gold) 22%, transparent)", fg: "#8a5f10" },
  red: { bg: "color-mix(in srgb, var(--red) 20%, transparent)", fg: "#8f2c23" },
  blue: { bg: "color-mix(in srgb, var(--blue) 20%, transparent)", fg: "#274d78" },
};
export function Pill({ children, tone = "chalk" }: { children: React.ReactNode; tone?: PillTone }) {
  const t = PILL_TONES[tone];
  return (
    <span style={{ background: t.bg, color: t.fg, fontSize: 12, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>
      {children}
    </span>
  );
}

/* ---------------- Empty state ---------------- */
export function EmptyState({ icon: Icon, title, body }: { icon: React.ElementType; title: string; body: string }) {
  return (
    <div style={{ textAlign: "center", padding: "48px 20px", color: "var(--text-faint)" }}>
      <Icon size={34} style={{ marginBottom: 10, opacity: 0.6 }} />
      <div className="sh-display" style={{ fontWeight: 700, fontSize: 16, color: "var(--text)", marginBottom: 4 }}>
        {title}
      </div>
      <div style={{ fontSize: 13.5 }}>{body}</div>
    </div>
  );
}

/* ---------------- Skeleton loaders ---------------- */
export function Skeleton({ height = 14, width = "100%", radius = 6 }: { height?: number; width?: number | string; radius?: number }) {
  return <div className="sh-shimmer" style={{ height, width, borderRadius: radius }} />;
}
export function SkeletonCard() {
  return (
    <Card animate={false} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <Skeleton height={16} width="50%" />
      <Skeleton height={28} width="35%" />
      <Skeleton height={12} width="70%" />
    </Card>
  );
}
export function SkeletonList({ rows = 4 }: { rows?: number }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} height={40} />
      ))}
    </div>
  );
}

/* ---------------- Modal ---------------- */
export function Modal({ open, onClose, title, children, width = 480 }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; width?: number }) {
  if (!open) return null;
  return (
    <div
      style={{ position: "fixed", inset: 0, background: "var(--overlay)", zIndex: 150, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 26 }}
        onClick={(e) => e.stopPropagation()}
        className="card-surface"
        style={{ width: "100%", maxWidth: width, maxHeight: "88vh", overflow: "auto", boxShadow: "0 24px 60px -20px rgba(0,0,0,.5)" }}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 20px", borderBottom: "1px solid var(--border)", position: "sticky", top: 0, background: "var(--surface)" }}>
          <div className="sh-display" style={{ fontWeight: 700, fontSize: 17 }}>
            {title}
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-faint)" }}>
            <X size={20} />
          </button>
        </div>
        <div style={{ padding: 20 }}>{children}</div>
      </motion.div>
    </div>
  );
}

/* ---------------- Form fields ---------------- */
interface FieldWrap {
  label?: string;
}
export function Input({ label, ...props }: FieldWrap & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label style={{ display: "block", marginBottom: 14 }}>
      {label && <FieldLabel>{label}</FieldLabel>}
      <input {...props} style={fieldStyle} />
    </label>
  );
}
export function Textarea({ label, ...props }: FieldWrap & React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <label style={{ display: "block", marginBottom: 14 }}>
      {label && <FieldLabel>{label}</FieldLabel>}
      <textarea {...props} style={{ ...fieldStyle, fontFamily: "inherit", resize: "vertical" }} />
    </label>
  );
}
export function Select({ label, children, ...props }: FieldWrap & React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <label style={{ display: "block", marginBottom: 14 }}>
      {label && <FieldLabel>{label}</FieldLabel>}
      <select {...props} style={fieldStyle}>
        {children}
      </select>
    </label>
  );
}
function FieldLabel({ children }: { children: React.ReactNode }) {
  return <div style={{ fontSize: 12.5, fontWeight: 700, color: "var(--text-muted)", marginBottom: 6, textTransform: "uppercase", letterSpacing: 0.4 }}>{children}</div>;
}
const fieldStyle: React.CSSProperties = {
  width: "100%",
  padding: "10px 12px",
  borderRadius: 10,
  border: "1.5px solid var(--border)",
  fontSize: 14.5,
  outline: "none",
  background: "var(--surface)",
  color: "var(--text)",
};
