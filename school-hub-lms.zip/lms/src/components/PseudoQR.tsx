import { useMemo } from "react";

function hashStr(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}
function mulberry32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function PseudoQR({ value, size = 148 }: { value: string; size?: number }) {
  const cells = 21;
  const grid = useMemo(() => {
    const rand = mulberry32(hashStr(value));
    const g = Array.from({ length: cells }, () => Array.from({ length: cells }, () => rand() > 0.55));
    const stampFinder = (r0: number, c0: number) => {
      for (let r = 0; r < 7; r++)
        for (let c = 0; c < 7; c++) {
          const border = r === 0 || r === 6 || c === 0 || c === 6;
          const inner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
          g[r0 + r][c0 + c] = border || inner;
        }
    };
    stampFinder(0, 0);
    stampFinder(0, cells - 7);
    stampFinder(cells - 7, 0);
    return g;
  }, [value]);

  const cell = size / cells;
  return (
    <svg width={size} height={size} style={{ display: "block" }}>
      <rect width={size} height={size} fill="#fff" />
      {grid.map((row, r) => row.map((on, c) => (on ? <rect key={`${r}-${c}`} x={c * cell} y={r * cell} width={cell} height={cell} fill="#22301f" /> : null)))}
    </svg>
  );
}
