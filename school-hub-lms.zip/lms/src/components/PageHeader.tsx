export function PageHeader({ title, subtitle, right }: { title: string; subtitle?: string; right?: React.ReactNode }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 22 }}>
      <div>
        <div className="sh-display" style={{ fontSize: 25, fontWeight: 700 }}>{title}</div>
        {subtitle && <div style={{ fontSize: 13.5, color: "var(--text-faint)", marginTop: 3 }}>{subtitle}</div>}
      </div>
      {right}
    </div>
  );
}
