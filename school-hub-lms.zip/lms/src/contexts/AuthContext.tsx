import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import type { Role, UserProfile } from "@/types";

interface SignUpInput {
  email: string;
  password: string;
  fullName: string;
  role: Role;
}

interface AuthContextValue {
  session: Session | null;
  profile: UserProfile | null;
  loading: boolean;
  isConfigured: boolean;
  /** 5-minute cooldown after entering a dashboard before "log out / switch role" is allowed. */
  logoutLocked: boolean;
  logoutRemainingMs: number;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (input: SignUpInput) => Promise<{ error: string | null; needsVerification: boolean }>;
  signInWithOAuth: (provider: "google" | "facebook") => Promise<{ error: string | null }>;
  sendPasswordReset: (email: string) => Promise<{ error: string | null }>;
  updatePassword: (newPassword: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);
const LOGOUT_LOCK_MS = 5 * 60 * 1000;

async function fetchProfile(userId: string): Promise<UserProfile | null> {
  const { data, error } = await supabase.from("users").select("*").eq("id", userId).maybeSingle();
  if (error || !data) return null;
  return { id: data.id, email: data.email, fullName: data.full_name, role: data.role, avatarUrl: data.avatar_url };
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [loginAt, setLoginAt] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session) {
        setProfile(await fetchProfile(data.session.user.id));
        setLoginAt(Date.now());
      }
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      setSession(newSession);
      if (newSession) {
        setProfile(await fetchProfile(newSession.user.id));
        if (event === "SIGNED_IN") setLoginAt(Date.now());
      } else {
        setProfile(null);
        setLoginAt(null);
      }
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  }, []);

  const signUp = useCallback(async ({ email, password, fullName, role }: SignUpInput) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName, role } },
    });
    if (error) return { error: error.message, needsVerification: false };

    const userId = data.user?.id;
    if (userId) {
      // Create the profile row. If email confirmation is required, there may be
      // no session yet — this insert still works because our RLS policy checks
      // auth.uid() = id, and Supabase issues a JWT for the just-created user
      // even before the email is confirmed (confirmation only gates login).
      await supabase.from("users").upsert({ id: userId, email, full_name: fullName, role });
      if (role === "teacher") await supabase.from("teachers").upsert({ user_id: userId });
      if (role === "student") await supabase.from("students").upsert({ user_id: userId });
    }

    const needsVerification = !data.session;
    return { error: null, needsVerification };
  }, []);

  const signInWithOAuth = useCallback(async (provider: "google" | "facebook") => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider,
      options: { redirectTo: window.location.origin },
    });
    return { error: error?.message ?? null };
  }, []);

  const sendPasswordReset = useCallback(async (email: string) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    return { error: error?.message ?? null };
  }, []);

  const updatePassword = useCallback(async (newPassword: string) => {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    return { error: error?.message ?? null };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setLoginAt(null);
  }, []);

  const logoutRemainingMs = loginAt ? Math.max(0, LOGOUT_LOCK_MS - (now - loginAt)) : 0;
  const logoutLocked = logoutRemainingMs > 0;

  return (
    <AuthContext.Provider
      value={{
        session,
        profile,
        loading,
        isConfigured: isSupabaseConfigured,
        logoutLocked,
        logoutRemainingMs,
        signIn,
        signUp,
        signInWithOAuth,
        sendPasswordReset,
        updatePassword,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
