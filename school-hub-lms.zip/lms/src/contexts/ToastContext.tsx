import React, { createContext, useCallback, useContext, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Bell, AlertTriangle, CheckCircle2 } from "lucide-react";

export interface Toast {
  id: string;
  title: string;
  body?: string;
  variant?: "info" | "success" | "error";
}

interface ToastContextValue {
  pushToast: (title: string, body?: string, variant?: Toast["variant"]) => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

const ICONS: Record<NonNullable<Toast["variant"]>, React.ElementType> = {
  info: Bell,
  success: CheckCircle2,
  error: AlertTriangle,
};

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const pushToast = useCallback((title: string, body?: string, variant: Toast["variant"] = "info") => {
    const id = Math.random().toString(36).slice(2, 9);
    setToasts((t) => [...t, { id, title, body, variant }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 5500);
  }, []);

  return (
    <ToastContext.Provider value={{ pushToast }}>
      {children}
      <div style={{ position: "fixed", bottom: 18, right: 18, zIndex: 200, display: "flex", flexDirection: "column", gap: 8, maxWidth: 320 }}>
        <AnimatePresence>
          {toasts.map((t) => {
            const Icon = ICONS[t.variant ?? "info"];
            return (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 12, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, x: 40 }}
                transition={{ duration: 0.22 }}
                className="glass-card"
                style={{
                  background: "var(--sidebar-bg)",
                  color: "#fff",
                  padding: "12px 14px",
                  display: "flex",
                  gap: 10,
                  alignItems: "flex-start",
                  boxShadow: "0 12px 30px -10px rgba(0,0,0,.5)",
                }}
              >
                <Icon size={16} style={{ color: "var(--gold)", flexShrink: 0, marginTop: 2 }} />
                <div>
                  <div style={{ fontWeight: 700, fontSize: 13 }}>{t.title}</div>
                  {t.body && <div style={{ fontSize: 12, color: "#c9dccf" }}>{t.body}</div>}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used within a ToastProvider");
  return ctx;
}
