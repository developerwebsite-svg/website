import { supabase } from "@/lib/supabaseClient";
import type { Quiz } from "@/types";
import type { QuizzesRow, QuizQuestion } from "@/lib/database.types";

function mapRow(row: QuizzesRow): Quiz {
  return {
    id: row.id,
    joinCode: row.join_code,
    teacherId: row.teacher_id,
    title: row.title,
    subject: row.subject,
    difficulty: row.difficulty,
    questions: row.questions,
    published: row.published,
    publishedAt: row.published_at,
    createdAt: row.created_at,
  };
}

export async function listQuizzesForTeacher(teacherId: string): Promise<Quiz[]> {
  const { data, error } = await supabase
    .from("quizzes")
    .select("*")
    .eq("teacher_id", teacherId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map(mapRow);
}

export async function createQuiz(input: {
  teacherId: string;
  title: string;
  subject: string;
  difficulty: string;
  questions: QuizQuestion[];
  published: boolean;
}): Promise<Quiz> {
  const { data, error } = await supabase
    .from("quizzes")
    .insert({
      teacher_id: input.teacherId,
      title: input.title,
      subject: input.subject,
      difficulty: input.difficulty,
      questions: input.questions,
      published: input.published,
      published_at: input.published ? new Date().toISOString() : null,
    })
    .select("*")
    .single();
  if (error) throw error;
  return mapRow(data);
}

export async function updateQuiz(id: string, patch: Partial<{ title: string; questions: QuizQuestion[]; published: boolean; publishedAt: string | null }>): Promise<void> {
  const dbPatch: Record<string, unknown> = {};
  if (patch.title !== undefined) dbPatch.title = patch.title;
  if (patch.questions !== undefined) dbPatch.questions = patch.questions;
  if (patch.published !== undefined) dbPatch.published = patch.published;
  if (patch.publishedAt !== undefined) dbPatch.published_at = patch.publishedAt;
  const { error } = await supabase.from("quizzes").update(dbPatch).eq("id", id);
  if (error) throw error;
}

export async function deleteQuiz(id: string): Promise<void> {
  const { error } = await supabase.from("quizzes").delete().eq("id", id);
  if (error) throw error;
}

export async function findQuizByJoinCode(code: string): Promise<Quiz | null> {
  const { data, error } = await supabase.from("quizzes").select("*").eq("join_code", code.toUpperCase()).eq("published", true).maybeSingle();
  if (error || !data) return null;
  return mapRow(data);
}
