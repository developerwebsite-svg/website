import { supabase } from "@/lib/supabaseClient";
import type { Announcement } from "@/types";
import type { AnnouncementsRow } from "@/lib/database.types";

function mapRow(row: AnnouncementsRow): Announcement {
  return {
    id: row.id,
    authorId: row.author_id,
    authorName: row.author_name,
    title: row.title,
    body: row.body,
    createdAt: row.created_at,
  };
}

export async function listAnnouncements(): Promise<Announcement[]> {
  const { data, error } = await supabase.from("announcements").select("*").order("created_at", { ascending: false }).limit(50);
  if (error) throw error;
  return (data ?? []).map(mapRow);
}

export async function postAnnouncement(input: { authorId: string; authorName: string; title: string; body: string }): Promise<Announcement> {
  const { data, error } = await supabase
    .from("announcements")
    .insert({ author_id: input.authorId, author_name: input.authorName, title: input.title, body: input.body })
    .select("*")
    .single();
  if (error) throw error;

  // Fan out a notification to every student so the bell + realtime toast fire for them.
  const { data: students } = await supabase.from("users").select("id").eq("role", "student");
  if (students && students.length) {
    await supabase.from("notifications").insert(
      students.map((s) => ({
        user_id: s.id,
        category: "announcement" as const,
        title: `📢 ${input.title}`,
        body: input.body,
      }))
    );
  }

  return mapRow(data);
}

export async function deleteAnnouncement(id: string): Promise<void> {
  const { error } = await supabase.from("announcements").delete().eq("id", id);
  if (error) throw error;
}
