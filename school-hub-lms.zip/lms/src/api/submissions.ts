import { supabase } from "@/lib/supabaseClient";
import type { Submission } from "@/types";
import type { SubmissionsRow } from "@/lib/database.types";

function mapRow(row: SubmissionsRow): Submission {
  return {
    id: row.id,
    quizId: row.quiz_id,
    quizTitle: row.quiz_title,
    studentId: row.student_id,
    studentName: row.student_name,
    section: row.section,
    score: row.score,
    total: row.total,
    submittedAt: row.submitted_at,
  };
}

export async function listSubmissionsForTeacher(teacherId: string): Promise<Submission[]> {
  // RLS already scopes this to quizzes owned by the caller, but we still filter
  // via a join so a teacher only sees submissions for their own quizzes.
  const { data, error } = await supabase
    .from("submissions")
    .select("*, quizzes!inner(teacher_id)")
    .eq("quizzes.teacher_id", teacherId)
    .order("submitted_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map((row: any) => mapRow(row));
}

export async function listSubmissionsForStudent(studentId: string): Promise<Submission[]> {
  const { data, error } = await supabase
    .from("submissions")
    .select("*")
    .eq("student_id", studentId)
    .order("submitted_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map(mapRow);
}

export async function submitExam(input: {
  quizId: string;
  quizTitle: string;
  studentId: string | null;
  studentName: string;
  section: string;
  score: number;
  total: number;
}): Promise<Submission> {
  const { data, error } = await supabase
    .from("submissions")
    .insert({
      quiz_id: input.quizId,
      quiz_title: input.quizTitle,
      student_id: input.studentId,
      student_name: input.studentName,
      section: input.section,
      score: input.score,
      total: input.total,
    })
    .select("*")
    .single();
  if (error) throw error;
  return mapRow(data);
}

export async function updateSubmissionScore(id: string, score: number): Promise<void> {
  const { error } = await supabase.from("submissions").update({ score }).eq("id", id);
  if (error) throw error;
}
