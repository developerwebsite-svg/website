import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { ToastProvider } from "@/contexts/ToastContext";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/layout/ProtectedRoute";
import { DashboardLayout } from "@/components/layout/DashboardLayout";

import RoleSelectPage from "@/pages/RoleSelectPage";
import Login from "@/pages/auth/Login";
import Register from "@/pages/auth/Register";
import ForgotPassword from "@/pages/auth/ForgotPassword";
import ResetPassword from "@/pages/auth/ResetPassword";
import VerifyEmail from "@/pages/auth/VerifyEmail";

import TeacherDashboard from "@/pages/teacher/Dashboard";
import AIQuizCreator from "@/pages/teacher/AIQuizCreator";
import PublishedQuizzes from "@/pages/teacher/PublishedQuizzes";
import StudentResults from "@/pages/teacher/StudentResults";
import GradeViewer from "@/pages/teacher/GradeViewer";
import GradeCalculator from "@/pages/teacher/GradeCalculator";
import TeacherLeaderboard from "@/pages/teacher/Leaderboard";
import TeacherAnnouncements from "@/pages/teacher/Announcements";
import TeacherSettings from "@/pages/teacher/Settings";

import StudentHome from "@/pages/student/Home";
import JoinExam from "@/pages/student/JoinExam";
import MyGrades from "@/pages/student/MyGrades";
import StudentLeaderboard from "@/pages/student/Leaderboard";
import StudentAnnouncements from "@/pages/student/Announcements";

import "@/styles/theme.css";
import "@/styles/global.css";

export default function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<RoleSelectPage />} />
              <Route path="/login/:role" element={<Login />} />
              <Route path="/register/:role" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/verify-email" element={<VerifyEmail />} />

              <Route
                path="/teacher"
                element={
                  <ProtectedRoute role="teacher">
                    <DashboardLayout role="teacher" />
                  </ProtectedRoute>
                }
              >
                <Route index element={<TeacherDashboard />} />
                <Route path="creator" element={<AIQuizCreator />} />
                <Route path="published" element={<PublishedQuizzes />} />
                <Route path="results" element={<StudentResults />} />
                <Route path="grades" element={<GradeViewer />} />
                <Route path="calculator" element={<GradeCalculator />} />
                <Route path="leaderboard" element={<TeacherLeaderboard />} />
                <Route path="announcements" element={<TeacherAnnouncements />} />
                <Route path="settings" element={<TeacherSettings />} />
              </Route>

              <Route
                path="/student"
                element={
                  <ProtectedRoute role="student">
                    <DashboardLayout role="student" />
                  </ProtectedRoute>
                }
              >
                <Route index element={<StudentHome />} />
                <Route path="join" element={<JoinExam />} />
                <Route path="grades" element={<MyGrades />} />
                <Route path="leaderboard" element={<StudentLeaderboard />} />
                <Route path="announcements" element={<StudentAnnouncements />} />
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </BrowserRouter>
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}
