import { useCallback, useEffect, useState } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabaseClient";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/contexts/ToastContext";
import type { AppNotification, NotificationCategory } from "@/types";
import type { NotificationsRow } from "@/lib/database.types";

function mapRow(row: NotificationsRow): AppNotification {
  return {
    id: row.id,
    userId: row.user_id,
    category: row.category,
    title: row.title,
    body: row.body,
    read: row.read,
    createdAt: row.created_at,
  };
}

export function useNotifications() {
  const { profile } = useAuth();
  const { pushToast } = useToast();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!profile || !isSupabaseConfigured) {
      setNotifications([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", profile.id)
      .order("created_at", { ascending: false })
      .limit(50);
    if (!error && data) setNotifications(data.map(mapRow));
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    load();
  }, [load]);

  // Live updates via Supabase Realtime (Postgres changes on the notifications table).
  useEffect(() => {
    if (!profile || !isSupabaseConfigured) return;
    const channel = supabase
      .channel(`notifications-${profile.id}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${profile.id}` },
        (payload) => {
          const row = mapRow(payload.new as NotificationsRow);
          setNotifications((n) => [row, ...n]);
          pushToast(row.title, row.body ?? undefined);
          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            try {
              new Notification(row.title, { body: row.body ?? undefined });
            } catch {
              /* ignore */
            }
          }
        }
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "notifications", filter: `user_id=eq.${profile.id}` },
        (payload) => {
          const row = mapRow(payload.new as NotificationsRow);
          setNotifications((n) => n.map((x) => (x.id === row.id ? row : x)));
        }
      )
      .on(
        "postgres_changes",
        { event: "DELETE", schema: "public", table: "notifications", filter: `user_id=eq.${profile.id}` },
        (payload) => {
          const oldRow = payload.old as { id: string };
          setNotifications((n) => n.filter((x) => x.id !== oldRow.id));
        }
      )
      .subscribe();

    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }

    return () => {
      supabase.removeChannel(channel);
    };
  }, [profile, pushToast]);

  const markRead = useCallback(async (id: string) => {
    setNotifications((n) => n.map((x) => (x.id === id ? { ...x, read: true } : x)));
    await supabase.from("notifications").update({ read: true }).eq("id", id);
  }, []);

  const markAllRead = useCallback(async () => {
    if (!profile) return;
    setNotifications((n) => n.map((x) => ({ ...x, read: true })));
    await supabase.from("notifications").update({ read: true }).eq("user_id", profile.id).eq("read", false);
  }, [profile]);

  const remove = useCallback(async (id: string) => {
    setNotifications((n) => n.filter((x) => x.id !== id));
    await supabase.from("notifications").delete().eq("id", id);
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  return { notifications, unreadCount, loading, markRead, markAllRead, remove, reload: load };
}

/** Helper for other features to create a notification for a user (e.g. "quiz published"). */
export async function createNotification(userId: string, category: NotificationCategory, title: string, body?: string) {
  await supabase.from("notifications").insert({ user_id: userId, category, title, body });
}
