export type { Role, NotificationCategory, QuizQuestion } from "@/lib/database.types";
import type { QuizQuestion } from "@/lib/database.types";

export interface Quiz {
  id: string;
  joinCode: string;
  teacherId: string;
  title: string;
  subject: string;
  difficulty: string;
  questions: QuizQuestion[];
  published: boolean;
  publishedAt: string | null;
  createdAt: string;
}

export interface Submission {
  id: string;
  quizId: string;
  quizTitle: string;
  studentId: string | null;
  studentName: string;
  section: string | null;
  score: number;
  total: number;
  submittedAt: string;
}

export interface Announcement {
  id: string;
  authorId: string | null;
  authorName: string;
  title: string;
  body: string | null;
  createdAt: string;
}

export interface AppNotification {
  id: string;
  userId: string;
  category: "assignment" | "quiz" | "announcement" | "grade" | "attendance";
  title: string;
  body: string | null;
  read: boolean;
  createdAt: string;
}

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  role: "teacher" | "student";
  avatarUrl: string | null;
}

export const EXAM_SUBJECTS = ["TLE", "Value Education", "Math", "Science", "Mapeh", "AP", "English", "Filipino"] as const;
