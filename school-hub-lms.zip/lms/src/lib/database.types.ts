// Hand-written types mirroring supabase/schema.sql.
// For a fully generated version, run:
//   npx supabase gen types typescript --project-id <id> > src/lib/database.types.ts

export type Role = "teacher" | "student";
export type NotificationCategory = "assignment" | "quiz" | "announcement" | "grade" | "attendance";

export interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
}

export interface UsersRow {
  id: string;
  email: string;
  full_name: string;
  role: Role;
  avatar_url: string | null;
  created_at: string;
}

export interface QuizzesRow {
  id: string;
  join_code: string;
  teacher_id: string;
  title: string;
  subject: string;
  difficulty: string;
  questions: QuizQuestion[];
  published: boolean;
  published_at: string | null;
  created_at: string;
}

export interface SubmissionsRow {
  id: string;
  quiz_id: string;
  quiz_title: string;
  student_id: string | null;
  student_name: string;
  section: string | null;
  score: number;
  total: number;
  submitted_at: string;
}

export interface AnnouncementsRow {
  id: string;
  author_id: string | null;
  author_name: string;
  title: string;
  body: string | null;
  created_at: string;
}

export interface NotificationsRow {
  id: string;
  user_id: string;
  category: NotificationCategory;
  title: string;
  body: string | null;
  read: boolean;
  created_at: string;
}

export interface GradesRow {
  id: string;
  student_id: string;
  subject: string;
  category: string;
  weight: number;
  score: number;
  updated_at: string;
}

// Minimal `Database` shape so `createClient<Database>()` gets useful
// autocomplete without requiring full Supabase CLI codegen.
export interface Database {
  public: {
    Tables: {
      users: { Row: UsersRow; Insert: Partial<UsersRow> & { id: string; email: string; full_name: string; role: Role }; Update: Partial<UsersRow> };
      quizzes: { Row: QuizzesRow; Insert: Partial<QuizzesRow> & { teacher_id: string; title: string; subject: string; questions: QuizQuestion[] }; Update: Partial<QuizzesRow> };
      submissions: { Row: SubmissionsRow; Insert: Partial<SubmissionsRow> & { quiz_id: string; quiz_title: string; student_name: string; score: number; total: number }; Update: Partial<SubmissionsRow> };
      announcements: { Row: AnnouncementsRow; Insert: Partial<AnnouncementsRow> & { title: string }; Update: Partial<AnnouncementsRow> };
      notifications: { Row: NotificationsRow; Insert: Partial<NotificationsRow> & { user_id: string; category: NotificationCategory; title: string }; Update: Partial<NotificationsRow> };
      grades: { Row: GradesRow; Insert: Partial<GradesRow> & { student_id: string; subject: string; category: string; weight: number; score: number }; Update: Partial<GradesRow> };
    };
  };
}
